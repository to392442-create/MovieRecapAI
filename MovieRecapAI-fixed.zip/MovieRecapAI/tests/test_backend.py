import os
import tempfile
import unittest
from pathlib import Path

# Isolate test persistence before importing the FastAPI module.
TEST_DATA = tempfile.mkdtemp(prefix="movierecap-test-")
os.environ["MOVIERECAP_DATA_DIR"] = TEST_DATA
os.environ["COOKIE_SECURE"] = "false"

from fastapi.testclient import TestClient  # noqa: E402
from backend.main import RenderOptions, RenderRequest, SourceUrlRequest, app, build_ffmpeg_command, calculate_risk, parse_srt_text, split_scenes, timed_srt  # noqa: E402


class MovieRecapBackendTests(unittest.TestCase):
    def test_parses_timed_srt(self):
        cues = parse_srt_text(
            "1\n00:00:01,200 --> 00:00:03,500\nA first line\n\n2\n00:00:04,000 --> 00:00:06,000\nA second line"
        )
        self.assertEqual(len(cues), 2)
        self.assertEqual(cues[0]["startTime"], "00:00:01,200")
        self.assertAlmostEqual(cues[-1]["end"], 6.0)

    def test_rejects_invalid_srt(self):
        with self.assertRaises(ValueError):
            parse_srt_text("This does not contain a subtitle timeline.")

    def test_copyright_never_claims_safety(self):
        from backend.main import CopyrightRequest

        result = calculate_risk(CopyrightRequest(sourcePlatform="YouTube", isOriginal=False, willTransform=True))
        self.assertEqual(result["risk"], "High")
        self.assertIn("not legal advice", result["disclaimer"])
        self.assertTrue(result["highRiskExportWarning"])

    def test_health_and_capabilities(self):
        client = TestClient(app)
        health = client.get("/health")
        capabilities = client.get("/capabilities")
        self.assertEqual(health.status_code, 200)
        self.assertEqual(health.json()["status"], "ok")
        self.assertEqual(capabilities.status_code, 200)
        self.assertIn("ffmpeg", capabilities.json())

    def test_route_manifest_is_json_not_spa_fallback(self):
        client = TestClient(app)
        response = client.get("/manus-routes.json")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["routes"][0]["path"], "/")

    def test_session_creates_server_credit_state(self):
        client = TestClient(app)
        response = client.get("/session")
        self.assertEqual(response.status_code, 200)
        self.assertIn("credits", response.json())

    def test_short_recap_duration_is_valid(self):
        from backend.main import RecapRequest

        request = RecapRequest(srtId="ast_short", targetSeconds=3)
        self.assertEqual(request.targetSeconds, 3)

    def test_no_effect_render_has_explicit_video_filter_output(self):
        options = RenderOptions(quality="source")
        job = {"payload": {"options": options.model_dump(), "outputName": "test.mp4"}}
        movie = {"storedPath": "/tmp/movie.mp4", "metadata": {"duration": 20, "hasAudio": True}}
        audio = {"storedPath": "/tmp/audio.mp3", "metadata": {}}
        command, _ = build_ffmpeg_command(job, movie, audio, None, None)
        filters = command[command.index("-filter_complex") + 1]
        self.assertIn("[0:v]null[vstage]", filters)
        self.assertIn("-map", command)
        self.assertIn("[vstage]", command)

    def test_render_payload_carries_full_copyright_facts(self):
        request = RenderRequest(movieId="ast_movie", audioId="ast_audio")
        self.assertEqual(request.copyright.sourcePlatform, "Local upload")

    def test_scene_plan_splits_on_long_pauses(self):
        cues = parse_srt_text("1\n00:00:00,000 --> 00:00:01,000\nFirst.\n\n2\n00:00:05,000 --> 00:00:06,000\nSecond.\n")
        scenes = split_scenes(cues, pause_seconds=3)
        self.assertEqual(len(scenes), 2)

    def test_timed_subtitles_are_sentence_weighted(self):
        output = timed_srt("First sentence. A much longer second sentence.", 10)
        cues = parse_srt_text(output)
        self.assertEqual(len(cues), 2)
        self.assertEqual(cues[-1]["end"], 10)

    def test_source_url_accepts_supported_hosts_only(self):
        self.assertEqual(SourceUrlRequest(url="https://www.youtube.com/watch?v=demo").url, "https://www.youtube.com/watch?v=demo")
        with self.assertRaises(ValueError):
            SourceUrlRequest(url="https://example.com/video")


if __name__ == "__main__":
    unittest.main()
