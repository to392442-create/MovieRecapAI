# MovieRecap AI — Implementation Plan

## Product direction
MovieRecap AI will be delivered first as an **installable Android-friendly PWA** backed by a genuine Python/FastAPI service. This is intentionally not labelled a native MIT App Inventor APK: an incomplete WebViewer wrapper would not meet the requested modern Android file-URI requirements. The responsive app can be installed from Android Chrome and uses browser-safe file selection; the FastAPI API is separately usable by a future MIT App Inventor client.

## Scope implemented in this build

- **Mobile production console:** an Android-friendly stepper matching the provided navigation: Movie Input, Subtitle Input, AI Recap, Voice, Subtitle Style, Logo & Branding, Original Subtitle Blur, Copyright, Preview, Export, Project, Credits, Settings and Help.
- **Real client functions:** local movie preview; local SRT parser with validation and timeline; source file / SRT / logo selection; controls that create real server requests; project snapshot export/import in browser storage; job polling; clear blocked-capability/error states.
- **FastAPI backend:** requested health, capability, self-test, upload, job, output and copyright endpoints plus controlled endpoints for session, AI recap, TTS and cancellation. Browser project snapshots deliberately remain client-side JSON rather than being misrepresented as server project persistence. The API accepts multipart files, issues real opaque asset IDs/job IDs, records actual job status/progress, and authorizes completed MP4 downloads to the signed session that created them.
- **Recap engine:** server-side OpenAI-compatible completion call using only server environment credentials. The prompt forces one natural narrator, natural spoken Burmese terms (ကျနော်, သူဒို့, မိတ်ဆွေဒို့), no character-by-character dialogue or storybook writing, selected language and duration target. If no server AI credential exists, it explicitly fails instead of fabricating a recap.
- **Voice engine:** server-side OpenAI-compatible TTS call using only server environment credentials. It receives selected voice, style and speed. A user-uploaded narration audio asset is also accepted for real rendering when TTS is unavailable or a custom voice is desired.
- **Video engine:** FFprobe checks selected movies; FFmpeg renders selected source plus narration, styled subtitle file, logo, transforms and optional original-subtitle blur. FFmpeg stderr is parsed for real elapsed-time progress. Cancellation terminates the running FFmpeg process.
- **Server-side credits:** a signed HTTP-only session receives a stored public-credit allowance; recap/TTS/render consume credits server-side. An administrator unlock uses `ADMIN_TOKEN` held only by the server and receives unlimited credits. Session-only public allowances are practical for testing but do not constitute a full anti-abuse identity/billing system.
- **Copyright assessment:** rule-based assessment returns Low/Medium/High with rationale and source/license/permission/attribution information. It explicitly says no result guarantees copyright safety and requires a high-risk export acknowledgement.

## Deliberate boundaries

1. **No misleading AI fallback.** AI recap and TTS report an actionable `not configured` error until a server credential is present.
2. **No deceptive copyright promise.** The checker is a risk aid, not legal advice or proof of permission.
3. **Large-file persistence.** Local development stores uploaded media on the server filesystem. The production deployment requires durable object storage/object-volume configuration; Render Free’s ephemeral disk is not reliable for retained projects/outputs.
4. **Authentication / public abuse prevention.** Signed session credits prevent client-side credit editing, but production public access needs a real account/identity and payment layer before it is safe to call production-ready.
5. **Android distribution.** The PWA is Android-installable and backend-compatible with App Inventor. Building a signed native APK and an App Inventor content-URI upload extension is a distinct device-build phase and will not be claimed here.

## Architecture

```
Android PWA (React + Vite)
  ├── local preview + SRT validation + project state
  └── HTTPS calls with credentials to FastAPI
         ├── signed session + server-held credits (SQLite/MySQL-ready)
         ├── asset upload registry
         ├── AI recap / TTS integrations (server-only credentials)
         ├── copyright risk engine
         └── FFprobe + asynchronous FFmpeg worker
                 └── MP4 output + job progress
```

## Project structure

| Path | Responsibility |
| --- | --- |
| `client/src/pages/Home.tsx` | Responsive production-console UI, file handling, step navigation and API orchestration. |
| `client/src/index.css` | Mobile-first dark cinematic design system and responsive layout. |
| `backend/main.py` | FastAPI API, upload security, session/credit logic, AI/TTS, SRT parsing, FFmpeg jobs and static serving. |
| `backend/requirements.txt` | Python runtime dependencies for local and Docker environments. |
| `Dockerfile` | Production container: Node frontend build, Python backend, FFmpeg and Noto Myanmar fonts. |
| `tests/test_backend.py` | Deterministic checks for SRT parsing, copyright scoring and API health/capabilities. |
| `client/public/manus-routes.json` | Required web route manifest. |
| `TODO.md` | Feature-by-feature delivery status using the requested status vocabulary. |

## Design direction

Other low-probability styles considered: editorial light workspace (0.04), neon arcade cinema (0.03), pure Android Material utility (0.05). Chosen direction: **Cinematic control room**.

- **Design Movement:** Professional post-production console with a restrained cinema-grade dark interface.
- **Core Principles:** show the current production step; surface media state rather than placeholders; use strong visual hierarchy; make constraints and risks visible before destructive export.
- **Color Philosophy:** near-black/slate grounds the workspace, warm amber owns urgent production actions, teal signals healthy rendered state, and rose signals risk/cancellation.
- **Layout Paradigm:** a persistent vertical production rail drives a staggered editing canvas; mobile collapses this into a horizontal stage navigator above the active workspace.
- **Signature Elements:** numbered gold stage pills, matte “monitor” video panels, and timeline-track status bars.
- **Interaction Philosophy:** every action changes tangible application state, returns a server result, or remains disabled with the exact reason.
- **Animation:** restrained 160–220ms state transitions; active stage indicator slides, job bars move only when server progress changes; no decorative motion during video processing.
- **Typography System:** `Inter`/system sans for operational UI with Burmese-compatible `Noto Sans Myanmar` fallback; compact all-caps stage labels, readable normal-weight Burmese body copy.
- **Brand Essence:** An honest, practical recap-production cockpit for creators who need a narrated video workflow without pretending copyright or processing is automatic. **Focused, cinematic, candid.**
- **Brand Voice:** Clear and action-first: “Upload a source, then build the narration.” / “High risk needs your acknowledgement before render.”
- **Wordmark & Logo:** A split-frame play icon that becomes two subtitle lines, paired with the MovieRecap AI wordmark.
- **Signature Brand Color:** `#F6B83F` — Cinema amber.
