# MovieRecap AI

**MovieRecap AI** is an Android-friendly, installable web application (PWA) for producing narrated movie recaps. It combines a React production console with a genuine **Python/FastAPI + FFmpeg** backend. It does not falsely present itself as a completed native APK or MIT App Inventor project.

## What works in this build

| Area | Status |
| --- | --- |
| Browser/Android document-picker movie, SRT, narration-audio and logo selection | Implemented; Android device test still required |
| Local source preview and server-side FFprobe validation | Implemented |
| SRT parse/validation, cue timeline, FFmpeg subtitle styling | Implemented and locally tested |
| Natural narrator-only AI recap prompt, including Burmese rules | Implemented; requires server AI credential and has not been provider-run in this project |
| TTS voice generation, language/style/speed/gender preference | Implemented; requires server TTS credential and has not been provider-run in this project |
| FFmpeg MP4 rendering, logo, blur, rotation/flip/speed, real progress, cancellation | Implemented and locally tested |
| Copyright Low/Medium/High risk checker and high-risk acknowledgement gate | Implemented; not legal advice and never a safety guarantee |
| Server-side anonymous test credits and owner unlimited mode | Implemented; public production still requires accounts, rate limits and billing |
| Browser JSON project snapshots | Implemented; source media stays server-side and is bound to the browser session |
| Pro scene segmentation | Implemented: `/recap/plan` splits subtitle timeline by pauses and cue volume |
| Sentence-weighted narration subtitles | Implemented: `/subtitles/from-script` creates a timed SRT from the actual narration duration and export prefers it |
| YouTube/TikTok/Rednote source links | Implemented through optional server-side `yt-dlp`; use only content you own or have permission to download |
| Burmese step-by-step workflow UI | Implemented for the main production stages and mobile link/file input |
| SRT and original-audio translation | Implemented: `/subtitles/translate` preserves SRT timings; `/subtitles/from-audio-translate` extracts speech with server STT, translates it, and returns Burmese SRT |

## Start locally

```bash
pnpm dev
```

The application listens on `PORT` (default `3000`). Browse to the printed URL, choose **New recap project**, then follow the numbered left-hand workflow.

For type checks and tests:

```bash
pnpm check
pnpm test:backend
pnpm build:static
```

## Server configuration

Copy the names in [`.env.example`](.env.example) into your **server/deployment** secret configuration. Never place those values in the browser app.

| Variable | Purpose |
| --- | --- |
| `SESSION_SECRET` | Required in production; signs the HTTP-only application session. |
| `ADMIN_TOKEN` | Optional owner-mode unlock token. |
| `MANUS_API_URL` + `MANUS_API_KEY` or `OPENAI_API_KEY` | Server-side AI recap credential. |
| `OPENAI_API_KEY` + optional `OPENAI_API_BASE` | Server-side TTS credential. |
| `AI_MODEL`, `TTS_MODEL` | Optional provider model overrides. |
| `MOVIERECAP_DATA_DIR` | Local server media/job directory. It is not durable cloud storage. |
| `COOKIE_SECURE` | Keep `true` for HTTPS Preview/production; use `false` only for ordinary local HTTP testing. |

## HTTP API

The FastAPI server exposes the requested routes, with `/api` aliases for the browser UI:

| Route | Function |
| --- | --- |
| `GET /health` | Backend health and FFmpeg availability |
| `GET /capabilities` | Honest provider/storage/production readiness report |
| `POST /self-test` | Checks FFmpeg binary, data directory and configured providers |
| `POST /upload/movie`, `/upload/srt`, `/upload/audio`, `/upload/logo` | Validated multipart uploads with opaque asset IDs |
| `POST /upload/movie-url` | Downloads and validates an allowed YouTube/TikTok/Rednote link when `yt-dlp` is available |
| `POST /subtitles/translate` | Translates uploaded SRT cue text while preserving original timestamps |
| `POST /subtitles/from-audio-translate` | Extracts source speech, creates timestamped cues, translates them, and returns an SRT asset |
| `POST /recap/generate` | Server-side narrator-only AI recap |
| `POST /recap/plan` | Scene segmentation plan from validated SRT |
| `POST /tts/generate` | Server-side TTS narration asset |
| `POST /subtitles/from-script` | Sentence-weighted narration-timed SRT asset |
| `POST /copyright/check` | Low/Medium/High risk assessment and attribution suggestion |
| `POST /jobs/from-uploads` | Creates a real asynchronous FFmpeg job |
| `GET /jobs/{job_id}` | Real status/progress and authorized output URL |
| `POST /jobs/{job_id}/cancel` | Cancels a running/queued job and refunds its render credit |
| `GET /outputs/{filename}` | Signed-session-authorized final MP4 download |

## Deployment boundary

The root [`Dockerfile`](Dockerfile) builds the React UI and installs FastAPI, FFmpeg and Noto Myanmar fonts. A production container must receive `SESSION_SECRET` and any AI/TTS credentials as deployment secrets.

The local filesystem is intentional for development tests only. **Render Free filesystem is ephemeral**: configure durable object storage, account authentication, rate limits and billing before a public production launch. Docker was not built in this sandbox because Docker is unavailable here.

## Ownership and long-term use

The source code is committed to the project repository and can be transferred to the owner's GitHub, hosting, domain and storage accounts. The current Preview URL is a testing environment, not a lifetime hosting guarantee. A permanent owner-controlled release requires the owner to provide or create those accounts, configure deployment secrets, durable storage and domain DNS; do not put API keys in the browser or project snapshots.

## Current verification evidence

- 9 deterministic backend/API tests passed.
- TypeScript typecheck and Vite production build passed.
- Local API integration uploaded a movie, MP3 narration and SRT, then produced a downloadable 3-second MP4 with burned subtitles and original-subtitle blur.
- A separate no-effect render produced a downloadable MP4 and rejected output download without its signed session.
- Cancellation resulted in a terminal `cancelled` job with 0% progress and restored the render credit.

See [`TODO.md`](TODO.md) for honest implementation/production readiness status and [`plan.md`](plan.md) for architecture decisions.
