# MovieRecap AI — Delivery Checklist

Legend: ✅ Completed · ⚠️ Needs testing / environment configuration · ❌ Not implemented

## ✅ 1. Android-friendly source selection and preview — implemented / locally tested
- The mobile-first PWA provides real browser file controls for movie, SRT, narration audio and logo.
- It previews a selected movie locally before upload; it does not presume a normal Android filesystem path.
- The backend accepts multipart file streams, validates empty/unsupported files and returns real opaque asset IDs.
- Browser/PWA file selection uses the Android document picker through standard `<input type="file">`; cancellation leaves the state unchanged and unsupported/invalid files surface clear errors.
- **Android runtime tested:** ⚠️ Requires an Android device test. A native MIT App Inventor FilePicker/content-URI client is not claimed as complete in this build.

## ✅ 2. SRT selection, parsing and subtitle design — implemented / locally tested
- SRT uploads are decoded, parsed into timestamped cues and rejected if no valid cues exist or a cue ends before it begins.
- The UI shows cue count and timeline duration; the API stores parsed metadata server-side.
- Real FFmpeg render options include subtitle color, size and top/center/bottom placement with a Myanmar-capable Noto font.

## ✅ 3. AI recap generation — server implemented / ⚠️ credential-dependent
- `POST /recap/generate` calls a server-only Manus/OpenAI-compatible Chat Completions API and never exposes the API key to the browser.
- Prompt rules require one natural movie-recap narrator; prohibit character-by-character dialogue and storybook prose; target source duration; and apply natural spoken Burmese preferences (ကျနော်, သူဒို့, မိတ်ဆွေဒို့) when Burmese is selected.
- Burmese, English, Chinese, Japanese, Korean, Thai, Spanish and French are selectable.
- If the server lacks a configured credential, the API returns a clear non-fabricated error instead of a fake script.
- ✅ Pro scene-planning tool: `POST /recap/plan` segments validated SRT cues at long pauses/cue limits and the UI displays detected story sections before generation.

## ✅ 4. Voice and narration audio — server implemented / ⚠️ provider-dependent
- The UI provides single/multi narrator selection, male/female preference, professional/deep/scary/dark/emotional/sad/happy/action style and speed setting.
- `POST /tts/generate` uses a server-held OpenAI-compatible TTS credential, stores real MP3 output as an audio asset and returns a real audio asset ID.
- A user can alternatively upload narration audio for FFmpeg rendering.
- Automatic character speaker detection/manual character mapping is represented in UI scope but is **❌ not rendered as different character voices**; a complete multi-voice engine needs reliable speaker labels plus one TTS audio per speaker timeline.

## ✅ 5. Logo, original subtitle blur, transforms and FFmpeg MP4 — implemented / locally tested
- Logo upload and four-corner positioning are supported.
- The original-subtitle region can be blurred with strength and percentage area controls; transforms include rotation, horizontal/vertical flip, 0.5–2x speed and output quality.
- `POST /jobs/from-uploads` creates a real job ID and starts an async FFmpeg process; `GET /jobs/{job_id}` reports actual elapsed-time-derived progress, terminal errors and final `/outputs/{filename}` URL.
- `POST /jobs/{job_id}/cancel` terminates a running FFmpeg process where possible.
- **Production persistence:** ⚠️ local server files are suitable for testing only; Render Free’s disk is ephemeral and durable object storage is needed for retained uploaded movies and outputs.
- ✅ Pro subtitle timing: `POST /subtitles/from-script` creates sentence-weighted SRT cues from the real narration duration; export prefers this generated asset while preserving the original SRT for recap analysis.

## ✅ 6. Copyright risk assessment — implemented / locally tested
- `POST /copyright/check` returns Low/Medium/High based on platform, original-work declaration, license, permission and attribution details.
- Every result says it is not legal advice and never claims any video is 100% copyright safe.
- High-risk jobs require explicit acknowledgement before FFmpeg export; attribution text is returned.

## ✅ 7. Server-side credits and owner mode — implemented / locally tested
- Credits are stored on the backend database layer and charged server-side for AI recap, TTS and FFmpeg export.
- A signed HTTP-only session receives public credits; `ADMIN_TOKEN` held only in server environment unlocks unlimited owner credits.
- **Public production hardening:** ⚠️ signed anonymous sessions prevent direct browser-side editing but a public launch needs account authentication, rate limits and a payment/billing workflow to prevent repeated fresh-session abuse.

## ✅ 8. Project save/load, errors, self-test and UI — implemented / locally tested
- Projects can be saved/loaded as browser JSON snapshots and current state is retained in browser storage.
- Clear user-facing errors are shown for API, file, FFmpeg and capability failures.
- `GET /health`, `GET /capabilities` and `POST /self-test` run real service checks.
- The interface includes the requested menu flow: Home; Movie Input; Subtitle Input; AI Recap; Voice; Subtitle Style; Logo & Branding; Original Subtitle Blur; Copyright; Preview; Export; Project; Credits; Settings; Help.

## ❌ 9. Native Android APK / MIT App Inventor package
- Not delivered in this build. The app is an Android-installable PWA and the FastAPI multipart endpoints are designed to be consumable from MIT App Inventor, but a valid native `.aia` needs device-runtime validation of App Inventor’s scoped-storage/content-URI behavior and should not be fabricated as an untested wrapper.

## ⚠️ 10. Full integration / production readiness
- ✅ Local integration completed: source movie, narration MP3 and SRT were uploaded through the API; a real job ID progressed from processing to completed; FFmpeg rendered a 3-second downloadable MP4 with subtitle burn-in and original-subtitle blur enabled. A second no-effect render passed with session-authorized output download, and a cancelled render reached the terminal cancelled state with its render credit restored. Backend unit/API checks, TypeScript typecheck and production frontend build also passed.
- An Android device test, real AI/TTS run, durable storage, deployed MySQL migration and real Render deployment remain required before the product can be called production ready.
