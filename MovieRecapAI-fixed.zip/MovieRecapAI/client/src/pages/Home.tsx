import { type ReactNode, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  BookOpen,
  CircleHelp,
  Clapperboard,
  CloudUpload,
  Download,
  FileAudio,
  FileText,
  Film,
  FolderOpen,
  Gauge,
  HardDriveUpload,
  ImagePlus,
  LoaderCircle,
  LockKeyhole,
  Mic2,
  MonitorPlay,
  Play,
  Plus,
  RotateCcw,
  Save,
  Settings2,
  ShieldAlert,
  SlidersHorizontal,
  Sparkles,
  Square,
  Subtitles,
  Upload,
  Volume2,
  Wand2,
  X,
} from "lucide-react";
import { toast } from "sonner";

type StageId =
  | "home"
  | "movie"
  | "subtitles"
  | "recap"
  | "voice"
  | "subtitle-style"
  | "brand"
  | "blur"
  | "copyright"
  | "preview"
  | "export"
  | "project"
  | "credits"
  | "settings"
  | "help";

type Asset = {
  assetId: string;
  kind: "movie" | "srt" | "audio" | "logo";
  name: string;
  sizeBytes: number;
  metadata: Record<string, unknown>;
  createdAt: string;
};

type ScenePlan = { index: number; start: number; end: number; cueCount: number; estimatedWords: number; text: string };

type Capabilities = {
  ffmpeg: boolean;
  aiRecap: boolean;
  tts: boolean;
  database: string;
  durableStorage: boolean;
  creditSystem: boolean;
  androidClient: string;
  productionReady: boolean;
  notes: string[];
};

type Job = {
  jobId: string;
  status: "queued" | "processing" | "completed" | "failed" | "cancelled";
  progress: number;
  message: string;
  error?: string | null;
  outputUrl?: string;
};

type Options = {
  language: "Burmese" | "English" | "Chinese" | "Japanese" | "Korean" | "Thai" | "Spanish" | "French";
  narratorMode: "single" | "multi";
  voiceGender: "Female" | "Male";
  voice: "alloy" | "ash" | "ballad" | "coral" | "echo" | "fable" | "nova" | "onyx" | "sage" | "shimmer" | "verse";
  voiceStyle: "professional" | "deep" | "scary" | "dark" | "emotional" | "sad" | "happy" | "action";
  speed: number;
  subtitleColor: string;
  subtitleSize: number;
  subtitlePosition: "bottom" | "center" | "top";
  logoPosition: "top-left" | "top-right" | "bottom-left" | "bottom-right";
  blurOriginalSubtitles: boolean;
  blurStrength: number;
  blurX: number;
  blurY: number;
  blurWidth: number;
  blurHeight: number;
  rotation: "0" | "90" | "180" | "270";
  flipHorizontal: boolean;
  flipVertical: boolean;
  videoSpeed: number;
  quality: "720p" | "1080p" | "source";
  filename: string;
};

type CopyrightForm = {
  sourcePlatform: "YouTube" | "Facebook" | "TikTok" | "Local upload" | "Other";
  sourceUrl: string;
  creator: string;
  license: string;
  permission: string;
  attribution: string;
  isOriginal: boolean;
  willTransform: boolean;
};

type CopyrightResult = {
  risk: "Low" | "Medium" | "High";
  score: number;
  reasons: string[];
  attributionText: string;
  disclaimer: string;
  highRiskExportWarning: boolean;
};

type ProjectSnapshot = {
  version: 1;
  savedAt: string;
  options: Options;
  copyrightForm: CopyrightForm;
  copyrightResult: CopyrightResult | null;
  script: string;
  assets: Pick<ProjectState, "movie" | "srt" | "narrationSrt" | "audio" | "logo">;
};

type ProjectState = {
  movie: Asset | null;
  srt: Asset | null;
  narrationSrt: Asset | null;
  audio: Asset | null;
  logo: Asset | null;
};

const DEFAULT_OPTIONS: Options = {
  language: "Burmese",
  narratorMode: "single",
  voiceGender: "Female",
  voice: "nova",
  voiceStyle: "professional",
  speed: 1,
  subtitleColor: "#FFFFFF",
  subtitleSize: 24,
  subtitlePosition: "bottom",
  logoPosition: "top-right",
  blurOriginalSubtitles: false,
  blurStrength: 12,
  blurX: 0,
  blurY: 78,
  blurWidth: 100,
  blurHeight: 22,
  rotation: "0",
  flipHorizontal: false,
  flipVertical: false,
  videoSpeed: 1,
  quality: "720p",
  filename: "movie-recap",
};

const DEFAULT_COPYRIGHT: CopyrightForm = {
  sourcePlatform: "Local upload",
  sourceUrl: "",
  creator: "",
  license: "",
  permission: "",
  attribution: "",
  isOriginal: false,
  willTransform: true,
};

const STAGES: Array<{ id: StageId; number?: string; label: string; icon: typeof Film }> = [
  { id: "home", label: "မူလစာမျက်နှာ", icon: MonitorPlay },
  { id: "movie", number: "1", label: "ဗီဒီယိုထည့်ရန်", icon: Film },
  { id: "subtitles", number: "2", label: "SRT စာတန်းထည့်ရန်", icon: Subtitles },
  { id: "recap", number: "3", label: "AI အကျဉ်းချုပ်", icon: Sparkles },
  { id: "voice", number: "4", label: "AI အသံထည့်ရန်", icon: Mic2 },
  { id: "subtitle-style", number: "5", label: "စာတန်းပုံစံ", icon: SlidersHorizontal },
  { id: "brand", number: "6", label: "Logo / အမှတ်တံဆိပ်", icon: ImagePlus },
  { id: "blur", number: "7", label: "မူရင်းစာတန်းဖျောက်ရန်", icon: Square },
  { id: "copyright", number: "8", label: "မူပိုင်ခွင့်စစ်ရန်", icon: ShieldAlert },
  { id: "preview", number: "9", label: "ကြိုတင်ကြည့်ရန်", icon: MonitorPlay },
  { id: "export", number: "10", label: "MP4 ထုတ်ရန်", icon: Download },
  { id: "project", number: "11", label: "Project သိမ်းရန်", icon: FolderOpen },
  { id: "credits", number: "12", label: "အသုံးပြုခွင့်", icon: Gauge },
  { id: "settings", number: "13", label: "ဆက်တင်များ", icon: Settings2 },
  { id: "help", number: "14", label: "အကူအညီ", icon: CircleHelp },
];

const LANGUAGE_OPTIONS = ["Burmese", "English", "Chinese", "Japanese", "Korean", "Thai", "Spanish", "French"] as const;
const VOICE_STYLES = ["professional", "deep", "scary", "dark", "emotional", "sad", "happy", "action"] as const;
const VOICES = ["nova", "shimmer", "coral", "ballad", "sage", "alloy", "ash", "echo", "fable", "onyx", "verse"] as const;

function byteLabel(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function durationLabel(value: unknown) {
  const seconds = Number(value || 0);
  if (!seconds) return "—";
  const minutes = Math.floor(seconds / 60);
  return `${minutes}:${String(Math.round(seconds % 60)).padStart(2, "0")}`;
}

function asError(error: unknown) {
  return error instanceof Error ? error.message : "An unexpected error occurred.";
}

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`/api${path}`, { credentials: "include", ...init });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload?.error?.message || payload?.detail || `Request failed (${response.status}).`);
  }
  return payload as T;
}

function FieldLabel({ children, hint }: { children: ReactNode; hint?: string }) {
  return (
    <div className="field-label">
      <span>{children}</span>
      {hint ? <small>{hint}</small> : null}
    </div>
  );
}

function AssetTile({ asset, empty, icon: Icon, onChange, onClear }: { asset: Asset | null; empty: string; icon: typeof Film; onChange: () => void; onClear?: () => void }) {
  return (
    <div className={`asset-tile ${asset ? "is-ready" : ""}`}>
      <div className="asset-icon"><Icon size={20} /></div>
      <div className="asset-copy">
        <strong>{asset?.name || empty}</strong>
        <span>{asset ? `${byteLabel(asset.sizeBytes)} · Ready on server` : "No upload selected"}</span>
      </div>
      <button className="icon-action" onClick={asset && onClear ? onClear : onChange} title={asset ? "Remove" : "Select file"}>
        {asset && onClear ? <X size={18} /> : <Upload size={18} />}
      </button>
    </div>
  );
}

function Toggle({ checked, onChange, label, description }: { checked: boolean; onChange: (value: boolean) => void; label: string; description?: string }) {
  return (
    <label className="toggle-row">
      <span>
        <strong>{label}</strong>
        {description ? <small>{description}</small> : null}
      </span>
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} />
      <i aria-hidden="true" />
    </label>
  );
}

export default function Home() {
  const [active, setActive] = useState<StageId>("home");
  const [assets, setAssets] = useState<ProjectState>({ movie: null, srt: null, narrationSrt: null, audio: null, logo: null });
  const [options, setOptions] = useState<Options>(DEFAULT_OPTIONS);
  const [copyrightForm, setCopyrightForm] = useState<CopyrightForm>(DEFAULT_COPYRIGHT);
  const [copyrightResult, setCopyrightResult] = useState<CopyrightResult | null>(null);
  const [capabilities, setCapabilities] = useState<Capabilities | null>(null);
  const [credits, setCredits] = useState<string | number>("—");
  const [isAdmin, setIsAdmin] = useState(false);
  const [script, setScript] = useState("");
  const [job, setJob] = useState<Job | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [moviePreviewUrl, setMoviePreviewUrl] = useState<string | null>(null);
  const [sourceUrl, setSourceUrl] = useState("");
  const [srtSummary, setSrtSummary] = useState<string>("");
  const [ownerToken, setOwnerToken] = useState("");
  const [highRiskAcknowledged, setHighRiskAcknowledged] = useState(false);
  const [isHydrated, setIsHydrated] = useState(false);
  const [scenePlan, setScenePlan] = useState<ScenePlan[]>([]);
  const movieInput = useRef<HTMLInputElement>(null);
  const srtInput = useRef<HTMLInputElement>(null);
  const audioInput = useRef<HTMLInputElement>(null);
  const logoInput = useRef<HTMLInputElement>(null);
  const projectInput = useRef<HTMLInputElement>(null);

  const sourceDuration = useMemo(() => Number(assets.movie?.metadata.duration || assets.srt?.metadata.duration || 0), [assets.movie, assets.srt]);
  const completedStages = useMemo(() => {
    let count = 0;
    if (assets.movie) count += 1;
    if (assets.srt) count += 1;
    if (script) count += 1;
    if (assets.audio) count += 1;
    if (job?.status === "completed") count += 1;
    return count;
  }, [assets, script, job]);

  const patchOptions = (patch: Partial<Options>) => setOptions((current) => ({ ...current, ...patch }));
  const patchCopyright = (patch: Partial<CopyrightForm>) => {
    setCopyrightForm((current) => ({ ...current, ...patch }));
    setCopyrightResult(null);
    setHighRiskAcknowledged(false);
  };

  useEffect(() => {
    const saved = localStorage.getItem("movierecap-draft-v1");
    if (saved) {
      try {
        const snapshot = JSON.parse(saved) as Partial<ProjectSnapshot>;
        if (snapshot.options) setOptions({ ...DEFAULT_OPTIONS, ...snapshot.options });
        if (snapshot.copyrightForm) setCopyrightForm({ ...DEFAULT_COPYRIGHT, ...snapshot.copyrightForm });
        if (snapshot.copyrightResult) setCopyrightResult(snapshot.copyrightResult);
        if (snapshot.script) setScript(snapshot.script);
        if (snapshot.assets) setAssets((current) => ({ ...current, ...snapshot.assets }));
      } catch {
        localStorage.removeItem("movierecap-draft-v1");
      }
    }
    setIsHydrated(true);
    void (async () => {
      try {
        const [session, caps] = await Promise.all([api<{ credits: number | string; isAdmin: boolean }>("/session"), api<Capabilities>("/capabilities")]);
        setCredits(session.credits);
        setIsAdmin(session.isAdmin);
        setCapabilities(caps);
      } catch (error) {
        toast.error("Backend connection failed", { description: asError(error) });
      }
    })();
  }, []);

  useEffect(() => {
    if (!isHydrated) return;
    const snapshot: ProjectSnapshot = { version: 1, savedAt: new Date().toISOString(), options, copyrightForm, copyrightResult, script, assets };
    localStorage.setItem("movierecap-draft-v1", JSON.stringify(snapshot));
  }, [assets, copyrightForm, copyrightResult, isHydrated, options, script]);

  useEffect(() => {
    if (!job || ["completed", "failed", "cancelled"].includes(job.status)) return;
    const timer = window.setInterval(() => {
      void api<Job>(`/jobs/${job.jobId}`)
        .then((next) => {
          setJob(next);
          if (next.status === "completed") {
            toast.success("Final MP4 is ready", { description: "Download it from Export." });
            setCredits((previous) => previous);
          }
          if (next.status === "failed") toast.error("FFmpeg render failed", { description: next.error || next.message });
        })
        .catch((error) => toast.error("Could not refresh job status", { description: asError(error) }));
    }, 1400);
    return () => window.clearInterval(timer);
  }, [job]);

  useEffect(() => () => {
    if (moviePreviewUrl?.startsWith("blob:")) URL.revokeObjectURL(moviePreviewUrl);
  }, [moviePreviewUrl]);

  const refreshSession = async () => {
    const session = await api<{ credits: number | string; isAdmin: boolean }>("/session");
    setCredits(session.credits);
    setIsAdmin(session.isAdmin);
  };

  const upload = async (kind: Asset["kind"], file: File | undefined) => {
    if (!file) return;
    setBusy(`upload-${kind}`);
    try {
      if (kind === "srt") {
        const text = await file.text();
        const cueCount = (text.match(/\d{2}:\d{2}:\d{2}[,.]\d{3}\s+-->/g) || []).length;
        if (!cueCount) throw new Error("This file does not contain valid SRT timeline rows.");
        setSrtSummary(`${cueCount} timeline cue${cueCount === 1 ? "" : "s"} found locally; validating on server…`);
      }
      const formData = new FormData();
      formData.append("file", file);
      const response = await api<{ upload: Asset }>(`/upload/${kind}`, { method: "POST", body: formData });
      setAssets((current) => ({ ...current, [kind]: response.upload }));
      if (kind === "movie") {
        if (moviePreviewUrl?.startsWith("blob:")) URL.revokeObjectURL(moviePreviewUrl);
        setMoviePreviewUrl(URL.createObjectURL(file));
      }
      if (kind === "srt") {
        const metadata = response.upload.metadata;
        setSrtSummary(`${metadata.cueCount || "Valid"} cues · ${durationLabel(metadata.duration)} timeline · server-validated`);
      }
      toast.success(`${kind === "srt" ? "Subtitle" : kind[0].toUpperCase() + kind.slice(1)} upload ready`, { description: response.upload.name });
    } catch (error) {
      setSrtSummary(kind === "srt" ? "Subtitle validation failed." : srtSummary);
      toast.error("Upload was not accepted", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const downloadLinkedMovie = async () => {
    if (!sourceUrl.trim()) return toast.error("ဗီဒီယိုလင့်ခ် ထည့်ပါ", { description: "YouTube, TikTok သို့မဟုတ် Rednote link တစ်ခုထည့်ပါ။" });
    setBusy("movie-url");
    try {
      const response = await api<{ upload: Asset }>("/upload/movie-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: sourceUrl.trim() }),
      });
      setAssets((current) => ({ ...current, movie: response.upload }));
      setMoviePreviewUrl(null);
      toast.success("ဗီဒီယိုလင့်ခ် အဆင်သင့်ဖြစ်ပါပြီ", { description: response.upload.name });
    } catch (error) {
      toast.error("လင့်ခ်မှ ဗီဒီယိုမရယူနိုင်ပါ", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const removeAsset = (kind: keyof ProjectState) => {
    setAssets((current) => ({ ...current, [kind]: null }));
    if (kind === "movie") {
      if (moviePreviewUrl?.startsWith("blob:")) URL.revokeObjectURL(moviePreviewUrl);
      setMoviePreviewUrl(null);
    }
    toast.message(`${kind} cleared from this project`, { description: "The existing server upload is not deleted automatically." });
  };

  const generateRecap = async () => {
    if (!assets.srt) return toast.error("Add an SRT file first", { description: "AI Recap needs server-validated subtitle cues." });
    setBusy("recap");
    try {
      const response = await api<{ script: string; estimatedSeconds: number; credit: { credits: number | string; isAdmin: boolean } }>("/recap/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ srtId: assets.srt.assetId, language: options.language, narratorMode: options.narratorMode, targetSeconds: Math.max(1, sourceDuration || Number(assets.srt.metadata.duration) || 60) }),
      });
      setScript(response.script);
      setCredits(response.credit.credits);
      setIsAdmin(response.credit.isAdmin);
      toast.success("AI recap generated", { description: `Estimated narration: ${durationLabel(response.estimatedSeconds)}` });
      setActive("voice");
    } catch (error) {
      toast.error("AI recap was not generated", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const analyzeScenes = async () => {
    if (!assets.srt) return toast.error("Add an SRT file first");
    setBusy("scene-plan");
    try {
      const response = await api<{ scenes: ScenePlan[] }>("/recap/plan", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ srtId: assets.srt.assetId, maxCuesPerScene: 40, pauseSeconds: 3 }) });
      setScenePlan(response.scenes);
      toast.success("Scene plan ready", { description: `${response.scenes.length} story sections detected.` });
    } catch (error) {
      toast.error("Scene analysis failed", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const translateSrt = async () => {
    if (!assets.srt) return toast.error("SRT ဖိုင်အရင်ထည့်ပါ");
    setBusy("translate-srt");
    try {
      const response = await api<{ upload: Asset; credit: { credits: number | string; isAdmin: boolean } }>("/subtitles/translate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ srtId: assets.srt.assetId, targetLanguage: "Burmese" }) });
      setAssets((current) => ({ ...current, srt: response.upload }));
      setCredits(response.credit.credits);
      setIsAdmin(response.credit.isAdmin);
      setSrtSummary(`မြန်မာလို ဘာသာပြန်ပြီးပါပြီ · ${response.upload.metadata.cueCount} cues · မူရင်း timing မပြောင်းပါ`);
      toast.success("SRT ကို မြန်မာလို ဘာသာပြန်ပြီးပါပြီ");
    } catch (error) {
      toast.error("SRT ဘာသာပြန်မအောင်မြင်ပါ", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const translateFromAudio = async () => {
    if (!assets.movie) return toast.error("Video ဖိုင်အရင်ထည့်ပါ");
    setBusy("translate-audio");
    try {
      const response = await api<{ upload: Asset; credit: { credits: number | string; isAdmin: boolean } }>("/subtitles/from-audio-translate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ movieId: assets.movie.assetId, targetLanguage: "Burmese" }) });
      setAssets((current) => ({ ...current, srt: response.upload }));
      setCredits(response.credit.credits);
      setIsAdmin(response.credit.isAdmin);
      setSrtSummary(`မူရင်းအသံကို စာသားဖော်ပြီး မြန်မာလို ဘာသာပြန်ပြီးပါပြီ · ${response.upload.metadata.cueCount} cues`);
      toast.success("အသံကို မြန်မာ SRT အဖြစ်ပြောင်းပြီးပါပြီ");
    } catch (error) {
      toast.error("အသံမှ မြန်မာ SRT မထုတ်နိုင်ပါ", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const createTimedSubtitles = async () => {
    if (!script.trim() || !assets.audio) return toast.error("Generate narration audio first", { description: "Timed subtitles use the actual narration duration." });
    setBusy("timed-subtitles");
    try {
      const response = await api<{ upload: Asset }>("/subtitles/from-script", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: script, durationSeconds: Number(assets.audio.metadata.duration || 1) }) });
      setAssets((current) => ({ ...current, narrationSrt: response.upload }));
      toast.success("Narration-timed subtitles ready", { description: "The final export will use sentence-weighted timing." });
    } catch (error) {
      toast.error("Timed subtitle generation failed", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const generateVoice = async () => {
    if (!script.trim()) return toast.error("Create or paste a recap first", { description: "TTS only accepts actual narration text." });
    setBusy("voice");
    try {
      const response = await api<{ upload: Asset; credit: { credits: number | string; isAdmin: boolean } }>("/tts/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: script, language: options.language, voiceGender: options.voiceGender, voice: options.voice, style: options.voiceStyle, speed: options.speed }),
      });
      setAssets((current) => ({ ...current, audio: response.upload }));
      setCredits(response.credit.credits);
      setIsAdmin(response.credit.isAdmin);
      toast.success("Narration audio is ready", { description: response.upload.name });
      setActive("subtitle-style");
    } catch (error) {
      toast.error("TTS was not generated", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const checkCopyright = async () => {
    setBusy("copyright");
    try {
      const response = await api<CopyrightResult>("/copyright/check", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(copyrightForm) });
      setCopyrightResult(response);
      setHighRiskAcknowledged(false);
      toast.success("Copyright risk assessed", { description: `${response.risk} risk — read the reasons before export.` });
    } catch (error) {
      toast.error("Copyright check failed", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const startRender = async () => {
    if (!assets.movie) return toast.error("Add a movie first", { description: "The exporter needs a source movie asset." });
    if (!assets.audio) return toast.error("Narration audio is required", { description: "Generate TTS or upload a narration track first." });
    if (copyrightResult?.risk === "High" && !highRiskAcknowledged) return toast.error("Acknowledge the high-risk warning", { description: "This is required before the server will export." });
    setBusy("export");
    try {
      const response = await api<{ jobId: string; status: Job["status"]; progress: number; credit: { credits: number | string; isAdmin: boolean } }>("/jobs/from-uploads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          movieId: assets.movie.assetId,
          srtId: assets.srt?.assetId || null,
          narrationSrtId: assets.narrationSrt?.assetId || null,
          audioId: assets.audio.assetId,
          logoId: assets.logo?.assetId || null,
          filename: options.filename,
          options: {
            subtitleColor: options.subtitleColor,
            subtitleSize: options.subtitleSize,
            subtitlePosition: options.subtitlePosition,
            logoPosition: options.logoPosition,
            blurOriginalSubtitles: options.blurOriginalSubtitles,
            blurStrength: options.blurStrength,
            blurX: options.blurX,
            blurY: options.blurY,
            blurWidth: options.blurWidth,
            blurHeight: options.blurHeight,
            rotation: options.rotation,
            flipHorizontal: options.flipHorizontal,
            flipVertical: options.flipVertical,
            videoSpeed: options.videoSpeed,
            quality: options.quality,
          },
          copyright: copyrightForm,
          highRiskAcknowledged,
        }),
      });
      setJob({ jobId: response.jobId, status: response.status, progress: response.progress, message: "Render job has been accepted." });
      setCredits(response.credit.credits);
      setIsAdmin(response.credit.isAdmin);
      setActive("export");
      toast.success("FFmpeg job started", { description: "Progress is derived from the actual render timeline." });
    } catch (error) {
      toast.error("Export did not start", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const cancelJob = async () => {
    if (!job) return;
    setBusy("cancel");
    try {
      const response = await api<Job>(`/jobs/${job.jobId}/cancel`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reason: "Cancelled from MovieRecap AI" }) });
      setJob((current) => (current ? { ...current, ...response } : current));
      toast.message("Cancellation requested", { description: "FFmpeg is terminated where the current render process permits it." });
    } catch (error) {
      toast.error("Job could not be cancelled", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const saveProject = () => {
    const snapshot: ProjectSnapshot = { version: 1, savedAt: new Date().toISOString(), options, copyrightForm, copyrightResult, script, assets };
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${options.filename || "movie-recap"}-project.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Project snapshot downloaded", { description: "Uploaded files remain on this server and are only available to the same browser session." });
  };

  const loadProject = async (file: File | undefined) => {
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text()) as ProjectSnapshot;
      if (parsed.version !== 1 || !parsed.options || !parsed.assets) throw new Error("This is not a MovieRecap AI project snapshot.");
      setOptions({ ...DEFAULT_OPTIONS, ...parsed.options });
      setCopyrightForm({ ...DEFAULT_COPYRIGHT, ...parsed.copyrightForm });
      setCopyrightResult(parsed.copyrightResult || null);
      setScript(parsed.script || "");
      setAssets({ movie: parsed.assets.movie || null, srt: parsed.assets.srt || null, narrationSrt: parsed.assets.narrationSrt || null, audio: parsed.assets.audio || null, logo: parsed.assets.logo || null });
      toast.success("Project settings loaded", { description: "Server files must still belong to this signed browser session." });
    } catch (error) {
      toast.error("Project import failed", { description: asError(error) });
    }
  };

  const unlockOwner = async () => {
    if (!ownerToken.trim()) return toast.error("Enter the owner token", { description: "This token is checked only by the server." });
    setBusy("owner");
    try {
      const response = await api<{ credits: number | string; isAdmin: boolean; message: string }>("/admin/unlock", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: ownerToken }) });
      setCredits(response.credits);
      setIsAdmin(response.isAdmin);
      setOwnerToken("");
      toast.success("Owner mode unlocked", { description: response.message });
    } catch (error) {
      toast.error("Owner mode was not unlocked", { description: asError(error) });
    } finally {
      setBusy(null);
    }
  };

  const stageNext = (next: StageId) => <button className="text-link" onClick={() => setActive(next)}>Continue to {STAGES.find((stage) => stage.id === next)?.label} <ArrowRight size={15} /></button>;

  const mainContent = () => {
    switch (active) {
      case "home":
        return (
          <>
            <section className="hero-block">
              <div>
                <p className="eyebrow"><span className="live-dot" /> LIVE PRODUCTION WORKSPACE</p>
                <h1>Turn source footage into an <em>honest, narrated recap.</em></h1>
                <p className="hero-copy">Upload the movie and subtitles, generate a one-narrator script, create narration, then let the server render a real MP4 with FFmpeg.</p>
                <div className="hero-actions">
                  <button className="primary-button" onClick={() => setActive("movie")}><Plus size={18} /> New recap project</button>
                  <button className="secondary-button" onClick={() => setActive("project")}><FolderOpen size={18} /> Load project</button>
                </div>
              </div>
              <div className="hero-status">
                <span>Pipeline readiness</span>
                <strong>{completedStages} <small>/ 5 key stages</small></strong>
                <div className="status-bars">{Array.from({ length: 5 }, (_, index) => <i key={index} className={index < completedStages ? "done" : ""} />)}</div>
                <p>{capabilities?.ffmpeg ? "FFmpeg engine detected" : "FFmpeg not detected"} · {capabilities?.database || "checking database"}</p>
              </div>
            </section>
            <section className="metric-row">
              <Metric icon={Film} title="Source" value={assets.movie ? "Ready" : "Missing"} detail={assets.movie ? durationLabel(assets.movie.metadata.duration) : "Add a movie"} tone={assets.movie ? "good" : "neutral"} />
              <Metric icon={Subtitles} title="Subtitles" value={assets.srt ? `${assets.srt.metadata.cueCount || "Valid"} cues` : "Optional"} detail={assets.srt ? durationLabel(assets.srt.metadata.duration) : "SRT improves recap accuracy"} tone={assets.srt ? "good" : "neutral"} />
              <Metric icon={Volume2} title="Narration" value={assets.audio ? "Ready" : "Waiting"} detail={assets.audio ? durationLabel(assets.audio.metadata.duration) : "Generate TTS or upload audio"} tone={assets.audio ? "good" : "neutral"} />
              <Metric icon={ShieldAlert} title="Copyright" value={copyrightResult?.risk || "Unchecked"} detail={copyrightResult ? "Risk is never a safety guarantee" : "Assess before export"} tone={copyrightResult?.risk === "High" ? "risk" : copyrightResult ? "good" : "neutral"} />
            </section>
            <section className="panel quick-start-panel">
              <div className="panel-heading"><div><p className="eyebrow">BUILD ORDER</p><h2>Your next production actions</h2></div><Clapperboard size={26} /></div>
              <div className="quick-steps">
                {[
                  ["1", "Add movie", Boolean(assets.movie), "movie"],
                  ["2", "Validate SRT", Boolean(assets.srt), "subtitles"],
                  ["3", "Generate narration", Boolean(script || assets.audio), "recap"],
                  ["4", "Check rights", Boolean(copyrightResult), "copyright"],
                  ["5", "Render MP4", job?.status === "completed", "export"],
                ].map(([number, label, done, id]) => <button key={String(id)} className={`quick-step ${done ? "is-done" : ""}`} onClick={() => setActive(id as StageId)}><b>{done ? <BadgeCheck size={17} /> : number}</b><span>{label}</span><ArrowRight size={15} /></button>)}
              </div>
            </section>
          </>
        );
      case "movie":
        return (
          <section className="stage-layout">
            <div className="stage-title"><p className="eyebrow">အဆင့် ၁ · ဗီဒီယိုထည့်ရန်</p><h1>ဗီဒီယိုကို အရင်ထည့်ပါ။</h1><p>ဖုန်းထဲက video file ရွေးနိုင်သလို YouTube, TikTok, Rednote link ကိုလည်း ထည့်နိုင်ပါတယ်။ ကိုယ်ပိုင်အသုံးပြုခွင့်ရှိတဲ့ content ကိုသာ အသုံးပြုပါ။</p></div>
            <div className="split-grid">
              <div className="panel drop-panel">
                <Film size={31} /><h2>{assets.movie ? "ဗီဒီယို ရပါပြီ" : "ဗီဒီယိုရွေးပါ"}</h2>
                <p>MP4, MOV, MKV, WebM, AVI သို့မဟုတ် M4V ဖိုင်များကို ထည့်နိုင်ပါတယ်။ တစ်နာရီကျော် video များလည်း server ရဲ့ သတ်မှတ်ထားသော file size အတွင်း လက်ခံနိုင်ပါတယ်။</p>
                <button className="primary-button" disabled={busy === "upload-movie"} onClick={() => movieInput.current?.click()}>{busy === "upload-movie" ? <LoaderCircle className="spin" size={18} /> : <CloudUpload size={18} />}{assets.movie ? "ဗီဒီယိုပြန်ရွေးရန်" : "ဖုန်းထဲမှ ဗီဒီယိုရွေးရန်"}</button>
                <input ref={movieInput} className="sr-only" type="file" accept="video/*,.mkv,.avi,.m4v" onChange={(event) => void upload("movie", event.target.files?.[0])} />
                {assets.movie ? <AssetTile asset={assets.movie} empty="No movie" icon={Film} onChange={() => movieInput.current?.click()} onClear={() => removeAsset("movie")} /> : null}
                <div className="url-input-row"><input value={sourceUrl} onChange={(event) => setSourceUrl(event.target.value)} placeholder="YouTube / TikTok / Rednote link" /><button className="secondary-button" disabled={busy === "movie-url"} onClick={() => void downloadLinkedMovie()}>{busy === "movie-url" ? <LoaderCircle className="spin" size={17} /> : <Download size={17} />}Link မှ ရယူရန်</button></div>
                <div className="small-callout">Link download tool မရပါက ဖုန်းထဲသို့ ကိုယ်တိုင် download လုပ်ထားသော video file ကို အပေါ်က button နဲ့ရွေးပါ။</div>
              </div>
              <div className="panel monitor-panel">
                <div className="monitor-top"><span><i /> ဗီဒီယိုကြည့်ရန်</span><small>{assets.movie ? `${assets.movie.metadata.width || "?"}×${assets.movie.metadata.height || "?"} · ${durationLabel(assets.movie.metadata.duration)}` : "ဗီဒီယိုမထည့်ရသေးပါ"}</small></div>
                {moviePreviewUrl ? <video className="source-video" src={moviePreviewUrl} controls playsInline /> : <div className="video-empty"><Play size={32} /><span>ဖိုင်ရွေးပြီးရင် ဒီနေရာမှာ preview ကြည့်နိုင်ပါမယ်</span></div>}
                <div className="monitor-footer"><span>{assets.movie?.metadata.hasAudio ? "မူရင်းအသံ ရှိပါတယ်" : assets.movie ? "မူရင်းအသံ မတွေ့ပါ" : "ဗီဒီယိုစောင့်နေပါတယ်"}</span>{stageNext("subtitles")}</div>
              </div>
            </div>
          </section>
        );
      case "subtitles":
        return (
          <section className="stage-layout">
            <div className="stage-title"><p className="eyebrow">အဆင့် ၂ · SRT စာတန်းထည့်ရန်</p><h1>စာတန်းဖိုင်ကို ထည့်ပါ။</h1><p>စာတန်း timing မှန်မမှန် server က စစ်ပေးပြီးမှ AI အကျဉ်းချုပ်နဲ့ နောက်ဆုံး video မှာ အသုံးပြုပါမယ်။</p></div>
            <div className="split-grid wide-left">
              <div className="panel">
                <div className="panel-heading"><div><h2>SRT စာတန်း timeline</h2><p>AI အကျဉ်းချုပ်နဲ့ အသံနဲ့စာတန်းညီဖို့ SRT ဖိုင်က အရေးကြီးပါတယ်။</p></div><Subtitles size={25} /></div>
                <button className="upload-stripe" disabled={busy === "upload-srt"} onClick={() => srtInput.current?.click()}>{busy === "upload-srt" ? <LoaderCircle className="spin" size={18} /> : <FileText size={18} />}<span><strong>{assets.srt ? "Replace SRT subtitle" : "Choose SRT subtitle file"}</strong><small>{srtSummary || "UTF-8 or UTF-16 SRT; text files only when they contain valid SRT rows."}</small></span><Upload size={18} /></button>
                <input ref={srtInput} className="sr-only" type="file" accept=".srt,.txt,text/plain" onChange={(event) => void upload("srt", event.target.files?.[0])} />
                <button className="secondary-button full-button" disabled={busy === "translate-audio" || !assets.movie} onClick={() => void translateFromAudio()}>{busy === "translate-audio" ? <LoaderCircle className="spin" size={18} /> : <Volume2 size={18} />}မူရင်းအသံမှ မြန်မာ SRT ထုတ်ရန်</button>
                {assets.srt ? <><div className="timeline-overview"><div><b>{String(assets.srt.metadata.cueCount || "—")}</b><span>parsed cues</span></div><div><b>{durationLabel(assets.srt.metadata.duration)}</b><span>timeline duration</span></div><div><b>Server</b><span>validated</span></div><button className="text-link danger-link" onClick={() => removeAsset("srt")}>Remove SRT</button></div><button className="secondary-button full-button" disabled={busy === "translate-srt"} onClick={() => void translateSrt()}>{busy === "translate-srt" ? <LoaderCircle className="spin" size={18} /> : <Wand2 size={18} />}SRT ကို မြန်မာလို ဘာသာပြန်ရန်</button></> : null}
              </div>
              <aside className="note-card"><AlertTriangle size={19} /><div><strong>What SRT parsing does—and does not do</strong><p>It validates timestamp cues and gives the AI a timeline. It does not prove speakers, translate dialogue, or remove copyright risk.</p></div></aside>
            </div>
            {stageNext("recap")}
          </section>
        );
      case "recap":
        return (
          <section className="stage-layout">
            <div className="stage-title"><p className="eyebrow">အဆင့် ၃ · AI အကျဉ်းချုပ်</p><h1>ရုပ်ရှင်အကျဉ်းချုပ် စာသားထုတ်ပါ။</h1><p>AI က SRT စာတန်းကိုဖတ်ပြီး ဇာတ်ကောင်စကားပြောပုံမဟုတ်ဘဲ narrator တစ်ယောက်တည်း ပြောသလို သဘာဝကျတဲ့ recap script ရေးပေးပါမယ်။</p></div>
            <div className="split-grid recap-grid">
              <div className="panel control-panel">
                <FieldLabel hint="Server-side only">Narration language</FieldLabel>
                <div className="choice-grid language-grid">{LANGUAGE_OPTIONS.map((language) => <button key={language} className={`choice ${options.language === language ? "selected" : ""}`} onClick={() => patchOptions({ language })}>{language}</button>)}</div>
                <FieldLabel>Voice approach</FieldLabel>
                <div className="segmented"><button className={options.narratorMode === "single" ? "selected" : ""} onClick={() => patchOptions({ narratorMode: "single" })}>Single narrator</button><button className={options.narratorMode === "multi" ? "selected" : ""} onClick={() => patchOptions({ narratorMode: "multi" })}>Multi-voice plan</button></div>
                <p className="input-note">Multi-voice mode records intent now; final per-character voice mapping is not claimed until speaker labels and separate timed audio tracks are implemented.</p>
                <button className="secondary-button full-button" disabled={busy === "scene-plan" || !assets.srt} onClick={() => void analyzeScenes()}>{busy === "scene-plan" ? <LoaderCircle className="spin" size={18} /> : <Sparkles size={18} />}Analyze scenes · Pro tool</button>
                {scenePlan.length ? <div className="small-callout"><strong>{scenePlan.length} scene sections detected.</strong><br />{scenePlan.slice(0, 3).map((scene) => `Scene ${scene.index}: ${durationLabel(scene.end - scene.start)} · ~${scene.estimatedWords} words`).join(" · ")}</div> : null}
                <div className="target-duration"><span>Source duration target</span><strong>{durationLabel(sourceDuration)}</strong><small>{assets.srt ? "Derived from uploaded media/subtitle timeline" : "Upload an SRT to enable AI recap"}</small></div>
                <button className="primary-button full-button" disabled={busy === "recap" || !assets.srt} onClick={() => void generateRecap()}>{busy === "recap" ? <LoaderCircle className="spin" size={18} /> : <Wand2 size={18} />}{capabilities?.aiRecap === false ? "AI credential required" : "AI အကျဉ်းချုပ်ထုတ်ရန်"}</button>
              </div>
              <div className="panel script-panel"><div className="panel-heading"><div><h2>Narration script</h2><p>{script ? "Edit the generated copy before making voice audio." : "The returned narration will appear here—no placeholder script is used."}</p></div><Sparkles size={24} /></div><textarea value={script} onChange={(event) => setScript(event.target.value)} placeholder="Generate an AI recap after uploading valid SRT subtitles, or paste your own narrator script here." /><div className="script-footer"><span>{script.trim() ? `${script.trim().split(/\s+/).length} words` : "No narration text"}</span>{stageNext("voice")}</div></div>
            </div>
          </section>
        );
      case "voice":
        return (
          <section className="stage-layout">
            <div className="stage-title"><p className="eyebrow">အဆင့် ၄ · AI အသံထည့်ရန်</p><h1>AI အသံကို ထည့်ပါ။</h1><p>အသံအမျိုးသား/အမျိုးသမီး၊ အသံပုံစံနဲ့ အမြန်နှုန်းကို ရွေးပြီး recap script ကို အသံဖိုင်အဖြစ်လုပ်ပါ။</p></div>
            <div className="split-grid voice-grid">
              <div className="panel control-panel">
                <div className="two-field"><div><FieldLabel>Voice preference</FieldLabel><div className="segmented"><button className={options.voiceGender === "Female" ? "selected" : ""} onClick={() => patchOptions({ voiceGender: "Female" })}>Female</button><button className={options.voiceGender === "Male" ? "selected" : ""} onClick={() => patchOptions({ voiceGender: "Male" })}>Male</button></div></div><div><FieldLabel>Provider voice</FieldLabel><select value={options.voice} onChange={(event) => patchOptions({ voice: event.target.value as Options["voice"] })}>{VOICES.map((voice) => <option key={voice} value={voice}>{voice}</option>)}</select></div></div>
                <FieldLabel>Performance style</FieldLabel><div className="choice-grid style-grid">{VOICE_STYLES.map((style) => <button key={style} className={`choice capitalize ${options.voiceStyle === style ? "selected" : ""}`} onClick={() => patchOptions({ voiceStyle: style })}>{style}</button>)}</div>
                <FieldLabel hint={`${options.speed.toFixed(2)}×`}>Narration speed</FieldLabel><input type="range" min="0.25" max="2" step="0.05" value={options.speed} onChange={(event) => patchOptions({ speed: Number(event.target.value) })} />
                <button className="primary-button full-button" disabled={busy === "voice" || !script.trim()} onClick={() => void generateVoice()}>{busy === "voice" ? <LoaderCircle className="spin" size={18} /> : <Mic2 size={18} />}{capabilities?.tts === false ? "TTS credential required" : "မြန်မာ AI အသံထုတ်ရန်"}</button>
              </div>
              <div className="panel upload-audio-panel"><div className="audio-orb"><Volume2 size={31} /></div><h2>{assets.audio ? "Narration track ready" : "Or upload narration audio"}</h2><p>MP3, WAV, M4A, AAC or OGG. This is useful for a custom human voice or when you do not configure TTS.</p><button className="secondary-button" disabled={busy === "upload-audio"} onClick={() => audioInput.current?.click()}>{busy === "upload-audio" ? <LoaderCircle className="spin" size={18} /> : <HardDriveUpload size={18} />}{assets.audio ? "Replace narration" : "Upload audio"}</button><input ref={audioInput} className="sr-only" type="file" accept="audio/*,.m4a,.aac,.ogg" onChange={(event) => void upload("audio", event.target.files?.[0])} />{assets.audio ? <AssetTile asset={assets.audio} empty="No audio" icon={FileAudio} onChange={() => audioInput.current?.click()} onClear={() => removeAsset("audio")} /> : null}<div className="small-callout">Auto scene-mood analysis and automatic named-speaker detection require a future scene-analysis/speaker-diarization service; they are not falsely marked ready here.</div></div>
            </div>
            {stageNext("subtitle-style")}
          </section>
        );
      case "subtitle-style":
        return (
          <section className="stage-layout">
            <div className="stage-title"><p className="eyebrow">အဆင့် ၅ · စာတန်းပုံစံ</p><h1>စာတန်းကို လှပဖတ်ရလွယ်အောင်ပြင်ပါ။</h1><p>စာတန်းအရောင်၊ အရွယ်အစား၊ အပေါ်/အလယ်/အောက်နေရာကိုရွေးပါ။ နောက်ဆုံး MP4 မှာ တကယ်ထည့်ပေးပါမယ်။</p></div>
            <div className="split-grid style-layout"><div className="panel control-panel"><div className="two-field"><div><FieldLabel>Caption color</FieldLabel><div className="color-input"><input type="color" value={options.subtitleColor} onChange={(event) => patchOptions({ subtitleColor: event.target.value })} /><code>{options.subtitleColor}</code></div></div><div><FieldLabel hint={`${options.subtitleSize}px`}>Caption size</FieldLabel><input type="range" min="12" max="72" value={options.subtitleSize} onChange={(event) => patchOptions({ subtitleSize: Number(event.target.value) })} /></div></div><FieldLabel>Caption position</FieldLabel><div className="segmented"><button className={options.subtitlePosition === "top" ? "selected" : ""} onClick={() => patchOptions({ subtitlePosition: "top" })}>Top</button><button className={options.subtitlePosition === "center" ? "selected" : ""} onClick={() => patchOptions({ subtitlePosition: "center" })}>Center</button><button className={options.subtitlePosition === "bottom" ? "selected" : ""} onClick={() => patchOptions({ subtitlePosition: "bottom" })}>Bottom</button></div><div className="subtitle-ready">{assets.narrationSrt ? <><BadgeCheck size={17} /> Sentence-timed narration subtitles ready.</> : assets.srt ? <><BadgeCheck size={17} /> Source SRT cues will be burned into the final output.</> : <><AlertTriangle size={17} /> No SRT asset: render can proceed, but no captions will be burned.</>}</div><button className="secondary-button full-button" disabled={busy === "timed-subtitles" || !script.trim() || !assets.audio} onClick={() => void createTimedSubtitles()}>{busy === "timed-subtitles" ? <LoaderCircle className="spin" size={18} /> : <Subtitles size={18} />}Create narration-timed subtitles</button></div><CaptionPreview options={options} /></div>
            {stageNext("brand")}
          </section>
        );
      case "brand":
        return (
          <section className="stage-layout"><div className="stage-title"><p className="eyebrow">STEP 06 · LOGO & BRANDING</p><h1>Place a brand mark without covering the story.</h1><p>PNG, JPG or WebP logos are accepted. The output pipeline overlays the image at the selected corner during FFmpeg render.</p></div><div className="split-grid"><div className="panel upload-logo-panel"><ImagePlus size={30} /><h2>{assets.logo ? "Logo ready for render" : "Upload logo"}</h2><p>Use a transparent PNG for the cleanest result.</p><button className="primary-button" disabled={busy === "upload-logo"} onClick={() => logoInput.current?.click()}>{busy === "upload-logo" ? <LoaderCircle className="spin" size={18} /> : <Upload size={18} />}{assets.logo ? "Replace logo" : "Choose logo"}</button><input ref={logoInput} className="sr-only" type="file" accept="image/png,image/jpeg,image/webp" onChange={(event) => void upload("logo", event.target.files?.[0])} />{assets.logo ? <AssetTile asset={assets.logo} empty="No logo" icon={ImagePlus} onChange={() => logoInput.current?.click()} onClear={() => removeAsset("logo")} /> : null}</div><div className="panel control-panel"><FieldLabel>Logo position</FieldLabel><div className="corner-grid">{(["top-left", "top-right", "bottom-left", "bottom-right"] as const).map((position) => <button key={position} className={`corner ${options.logoPosition === position ? "selected" : ""}`} onClick={() => patchOptions({ logoPosition: position })}><i /><span>{position.replace("-", " ")}</span></button>)}</div><p className="input-note">The engine scales the logo to 15% of video width; it does not stretch the source image.</p></div></div>{stageNext("blur")}</section>
        );
      case "blur":
        return (
          <section className="stage-layout"><div className="stage-title"><p className="eyebrow">STEP 07 · ORIGINAL SUBTITLE BLUR</p><h1>Mask original subtitles when your rights permit it.</h1><p>The server uses FFmpeg crop + boxblur on the selected percentage region. The guide below previews the selected region only; it is not a substituted final render.</p></div><div className="split-grid blur-layout"><div className="panel control-panel"><Toggle checked={options.blurOriginalSubtitles} onChange={(blurOriginalSubtitles) => patchOptions({ blurOriginalSubtitles })} label="Blur selected original-subtitle area" description="Applied in the FFmpeg export filter graph." />{options.blurOriginalSubtitles ? <div className="range-stack"><RangeControl label="Blur strength" value={options.blurStrength} min={1} max={40} onChange={(blurStrength) => patchOptions({ blurStrength })} /><RangeControl label="Area X" value={options.blurX} min={0} max={100} onChange={(blurX) => patchOptions({ blurX })} suffix="%" /><RangeControl label="Area Y" value={options.blurY} min={0} max={100} onChange={(blurY) => patchOptions({ blurY })} suffix="%" /><RangeControl label="Area width" value={options.blurWidth} min={1} max={100} onChange={(blurWidth) => patchOptions({ blurWidth })} suffix="%" /><RangeControl label="Area height" value={options.blurHeight} min={1} max={100} onChange={(blurHeight) => patchOptions({ blurHeight })} suffix="%" /></div> : null}</div><BlurGuide options={options} /></div>{stageNext("copyright")}</section>
        );
      case "copyright":
        return (
          <section className="stage-layout"><div className="stage-title"><p className="eyebrow">STEP 08 · COPYRIGHT</p><h1>Assess risk before you create an export.</h1><p>This tool gives a Low/Medium/High production risk signal—not legal advice, not a license, and never a promise of 100% safety.</p></div><div className="split-grid copyright-grid"><div className="panel control-panel"><div className="two-field"><div><FieldLabel>Source platform</FieldLabel><select value={copyrightForm.sourcePlatform} onChange={(event) => patchCopyright({ sourcePlatform: event.target.value as CopyrightForm["sourcePlatform"] })}>{["Local upload", "YouTube", "Facebook", "TikTok", "Other"].map((platform) => <option key={platform}>{platform}</option>)}</select></div><div><FieldLabel>Creator / rights holder</FieldLabel><input value={copyrightForm.creator} onChange={(event) => patchCopyright({ creator: event.target.value })} placeholder="e.g. studio or creator name" /></div></div><FieldLabel>Source URL</FieldLabel><input value={copyrightForm.sourceUrl} onChange={(event) => patchCopyright({ sourceUrl: event.target.value })} placeholder="https://…" /><FieldLabel>License or permission record</FieldLabel><textarea className="compact-textarea" value={copyrightForm.license} onChange={(event) => patchCopyright({ license: event.target.value })} placeholder="License terms, permission reference, or contract note" /><FieldLabel>Attribution text</FieldLabel><input value={copyrightForm.attribution} onChange={(event) => patchCopyright({ attribution: event.target.value })} placeholder="Credit text shown in description/caption where applicable" /><Toggle checked={copyrightForm.isOriginal} onChange={(isOriginal) => patchCopyright({ isOriginal })} label="This is original work" /><Toggle checked={copyrightForm.willTransform} onChange={(willTransform) => patchCopyright({ willTransform })} label="Recap is transformative" description="Transformation does not itself create permission." /><button className="primary-button full-button" disabled={busy === "copyright"} onClick={() => void checkCopyright()}>{busy === "copyright" ? <LoaderCircle className="spin" size={18} /> : <ShieldAlert size={18} />}Assess copyright risk</button></div><RiskCard result={copyrightResult} /></div></section>
        );
      case "preview":
        return (
          <section className="stage-layout"><div className="stage-title"><p className="eyebrow">STEP 09 · PREVIEW</p><h1>Review what is real before rendering.</h1><p>Source video plays locally, while the production summary reflects server uploads and FFmpeg settings. The exact branded/blurred result exists only after export.</p></div><div className="preview-grid"><div className="panel monitor-panel preview-monitor"><div className="monitor-top"><span><i /> PRE-RENDER REVIEW</span><small>{assets.movie ? "Local source" : "No source"}</small></div>{moviePreviewUrl ? <video className="source-video" src={moviePreviewUrl} controls playsInline /> : <div className="video-empty"><MonitorPlay size={32} /><span>Add a movie to preview source footage</span></div>}<div className="render-overlay-preview"><span style={{ color: options.subtitleColor, fontSize: `${Math.min(options.subtitleSize, 34)}px` }}>Movie recap subtitles</span></div></div><div className="panel review-list"><h2>Render manifest</h2><ReviewLine done={Boolean(assets.movie)} label="Movie source" value={assets.movie?.name || "Missing"} /><ReviewLine done={Boolean(assets.srt)} label="Subtitle timeline" value={assets.srt ? `${assets.srt.metadata.cueCount || "Valid"} cues` : "No captions"} /><ReviewLine done={Boolean(assets.audio)} label="Narration audio" value={assets.audio?.name || "Missing"} /><ReviewLine done={Boolean(assets.logo)} label="Logo layer" value={assets.logo?.name || "No logo"} /><ReviewLine done={Boolean(copyrightResult)} label="Copyright check" value={copyrightResult?.risk ? `${copyrightResult.risk} risk` : "Unchecked"} /><ReviewLine done={Boolean(options.blurOriginalSubtitles)} label="Original subtitle blur" value={options.blurOriginalSubtitles ? "Enabled" : "Off"} /><button className="primary-button full-button" onClick={() => setActive("export")}>Go to export <ArrowRight size={17} /></button></div></div></section>
        );
      case "export":
        return (
          <section className="stage-layout"><div className="stage-title"><p className="eyebrow">STEP 10 · EXPORT</p><h1>Render a final MP4 with real progress.</h1><p>Private owner mode မှာ credit ကန့်သတ်ချက်မရှိပါ။ Progress က FFmpeg ရဲ့ အမှန်တကယ်လုပ်ဆောင်မှုအပေါ်မူတည်ပါတယ်။</p></div><div className="split-grid export-grid"><div className="panel control-panel"><FieldLabel>Output filename</FieldLabel><input value={options.filename} onChange={(event) => patchOptions({ filename: event.target.value })} placeholder="movie-recap" /><FieldLabel>Output quality</FieldLabel><div className="segmented"><button className={options.quality === "720p" ? "selected" : ""} onClick={() => patchOptions({ quality: "720p" })}>720p</button><button className={options.quality === "1080p" ? "selected" : ""} onClick={() => patchOptions({ quality: "1080p" })}>1080p</button><button className={options.quality === "source" ? "selected" : ""} onClick={() => patchOptions({ quality: "source" })}>Source size</button></div><FieldLabel>Video transform</FieldLabel><div className="two-field"><select value={options.rotation} onChange={(event) => patchOptions({ rotation: event.target.value as Options["rotation"] })}><option value="0">No rotation</option><option value="90">Rotate 90°</option><option value="180">Rotate 180°</option><option value="270">Rotate 270°</option></select><select value={options.videoSpeed} onChange={(event) => patchOptions({ videoSpeed: Number(event.target.value) })}><option value="0.5">0.5× speed</option><option value="0.75">0.75× speed</option><option value="1">1× speed</option><option value="1.25">1.25× speed</option><option value="1.5">1.5× speed</option><option value="2">2× speed</option></select></div><Toggle checked={options.flipHorizontal} onChange={(flipHorizontal) => patchOptions({ flipHorizontal })} label="Flip horizontally" /><Toggle checked={options.flipVertical} onChange={(flipVertical) => patchOptions({ flipVertical })} label="Flip vertically" />{copyrightResult?.risk === "High" ? <label className="risk-ack"><input type="checkbox" checked={highRiskAcknowledged} onChange={(event) => setHighRiskAcknowledged(event.target.checked)} /><span><strong>High-risk export acknowledgement</strong><small>I understand this export is not guaranteed copyright-safe.</small></span></label> : null}<button className="primary-button full-button" disabled={busy === "export" || Boolean(job && ["queued", "processing"].includes(job.status))} onClick={() => void startRender()}>{busy === "export" ? <LoaderCircle className="spin" size={18} /> : <Clapperboard size={18} />}{job && ["queued", "processing"].includes(job.status) ? "Render in progress" : "Export final MP4"}</button></div><JobCard job={job} onCancel={() => void cancelJob()} cancelling={busy === "cancel"} /></div></section>
        );
      case "project":
        return (
          <section className="stage-layout"><div className="stage-title"><p className="eyebrow">STEP 11 · PROJECT</p><h1>Keep your production decisions portable.</h1><p>Project snapshots save settings, text, copyright information and server asset IDs. Raw source media remains on the server and must belong to this browser’s signed session.</p></div><div className="split-grid"><div className="panel project-action"><Save size={29} /><h2>Save project snapshot</h2><p>Download a JSON file containing the current project state. This is a real file you can keep or re-import later.</p><button className="primary-button" onClick={saveProject}><Download size={18} /> Save .json</button></div><div className="panel project-action"><FolderOpen size={29} /><h2>Load saved snapshot</h2><p>Restore a JSON snapshot on this browser. Existing upload IDs only work while their server files are retained.</p><button className="secondary-button" onClick={() => projectInput.current?.click()}><Upload size={18} /> Import .json</button><input ref={projectInput} className="sr-only" type="file" accept="application/json,.json" onChange={(event) => void loadProject(event.target.files?.[0])} /></div></div><div className="panel reset-panel"><div><strong>Start clean</strong><span>Clears local draft state and UI selections; it does not erase existing server files.</span></div><button className="secondary-button" onClick={() => { localStorage.removeItem("movierecap-draft-v1"); setAssets({ movie: null, srt: null, narrationSrt: null, audio: null, logo: null }); setOptions(DEFAULT_OPTIONS); setScript(""); setCopyrightForm(DEFAULT_COPYRIGHT); setCopyrightResult(null); setJob(null); setMoviePreviewUrl(null); toast.message("Local project state reset"); }}><RotateCcw size={17} /> Reset local project</button></div></section>
        );
      case "credits":
        return (
          <section className="stage-layout"><div className="stage-title"><p className="eyebrow">STEP 12 · CREDITS</p><h1>Credits live on the server, not in the app.</h1><p>Public test sessions start with a stored allowance. AI recap and TTS cost 1 credit each; a FFmpeg export costs 2. Owner mode is unlimited when the server has `ADMIN_TOKEN` configured.</p></div><div className="credit-hero"><div><p>AVAILABLE CREDIT BALANCE</p><strong>{isAdmin ? "Unlimited" : credits}</strong><span>{isAdmin ? "Owner mode active" : "Signed public session"}</span></div><Gauge size={56} /></div><div className="panel owner-panel"><LockKeyhole size={24} /><div><h2>Owner/Admin mode</h2><p>The secret token is sent only to the server for verification and is never stored in JavaScript, project snapshots, or the client bundle.</p></div><div className="owner-form"><input type="password" value={ownerToken} onChange={(event) => setOwnerToken(event.target.value)} placeholder="Owner token" autoComplete="off" /><button className="secondary-button" disabled={busy === "owner" || isAdmin} onClick={() => void unlockOwner()}>{busy === "owner" ? <LoaderCircle className="spin" size={16} /> : <LockKeyhole size={16} />}{isAdmin ? "Unlocked" : "Unlock"}</button></div></div><aside className="note-card"><AlertTriangle size={19} /><div><strong>Public launch hardening remains required</strong><p>Signed anonymous sessions stop direct credit editing, but real public billing must add user accounts, anti-abuse limits and a payment entitlement system before production launch.</p></div></aside></section>
        );
      case "settings":
        return (
          <section className="stage-layout"><div className="stage-title"><p className="eyebrow">STEP 13 · SETTINGS</p><h1>Inspect actual server capabilities.</h1><p>These flags are returned by FastAPI. A disabled capability is shown as disabled, not hidden behind a fake success state.</p></div><div className="panel capability-panel"><div className="panel-heading"><div><h2>Backend capability report</h2><p>Run a self-test to re-check FFmpeg, writable media directories and current provider configuration.</p></div><button className="secondary-button" onClick={() => void (async () => { setBusy("selftest"); try { const result = await api<{ ok: boolean; checks: Record<string, unknown> }>("/self-test", { method: "POST" }); toast[result.ok ? "success" : "error"](result.ok ? "Self-test passed" : "Self-test found a problem", { description: Object.entries(result.checks).map(([key, value]) => `${key}: ${String(value)}`).join(" · ") }); } catch (error) { toast.error("Self-test failed", { description: asError(error) }); } finally { setBusy(null); } })()}>{busy === "selftest" ? <LoaderCircle className="spin" size={17} /> : <Settings2 size={17} />}Run self-test</button></div><div className="capability-list"><Capability label="FFmpeg video engine" enabled={Boolean(capabilities?.ffmpeg)} detail="FFprobe validation, real render and progress parsing" /><Capability label="AI recap engine" enabled={Boolean(capabilities?.aiRecap)} detail="Requires server-held Manus/OpenAI-compatible credential" /><Capability label="TTS voice engine" enabled={Boolean(capabilities?.tts)} detail="Requires server-held OpenAI-compatible TTS credential" /><Capability label="Credit system" enabled={Boolean(capabilities?.creditSystem)} detail={`Persistence: ${capabilities?.database || "checking"}`} /><Capability label="Durable large-media storage" enabled={Boolean(capabilities?.durableStorage)} detail="Not configured in this local testing build" /></div>{capabilities?.notes?.map((note) => <div className="small-callout" key={note}>{note}</div>)}</div></section>
        );
      case "help":
        return (
          <section className="stage-layout"><div className="stage-title"><p className="eyebrow">STEP 14 · HELP</p><h1>Use the production order—one file stage at a time.</h1><p>MovieRecap AI does not silently skip dependencies. Each stage names what it needs and returns a real result or a clear reason it cannot proceed.</p></div><div className="panel help-panel"><HelpItem number="01" title="Choose movie" text="Choose a source video from Android/desktop storage. If Android cancels the picker, no file state is changed." /><HelpItem number="02" title="Add an SRT" text="Upload a subtitle file. The backend validates timestamps, extracts cues and uses the timeline for AI grounding." /><HelpItem number="03" title="Generate or paste recap" text="Generate a narrator script only when the server AI credential is available; otherwise paste your own text or configure the backend." /><HelpItem number="04" title="Make or upload voice" text="Use configured TTS or select an existing narration audio track. Rendering cannot begin without narration audio." /><HelpItem number="05" title="Assess risk, then export" text="Record source/permission information, acknowledge high risk if required, then start a real FFmpeg job and download the final MP4." /></div></section>
        );
    }
  };

  return (
    <main className="app-shell">
      <aside className="side-rail">
        <button className="brand" onClick={() => setActive("home")} aria-label="MovieRecap AI home"><span className="brand-mark"><Play size={15} fill="currentColor" /></span><span><strong>MovieRecap</strong><em>AI STUDIO</em></span></button>
        <nav>{STAGES.map((stage) => { const Icon = stage.icon; const stageDone = (stage.id === "movie" && assets.movie) || (stage.id === "subtitles" && assets.srt) || (stage.id === "recap" && script) || (stage.id === "voice" && assets.audio) || (stage.id === "export" && job?.status === "completed"); return <button key={stage.id} className={`nav-stage ${active === stage.id ? "active" : ""} ${stageDone ? "done" : ""}`} onClick={() => setActive(stage.id)}><span className="stage-marker">{stage.number || <Icon size={15} />}</span><span>{stage.label}</span>{stageDone ? <BadgeCheck size={14} /> : null}</button>; })}</nav>
        <div className="rail-bottom"><span className="api-pill"><i className={capabilities?.ffmpeg ? "online" : ""} /> API {capabilities ? "Connected" : "Checking"}</span><button onClick={() => setActive("credits")}><Gauge size={15} /> {isAdmin ? "Unlimited" : credits} credits</button></div>
      </aside>
      <section className="workspace">
        <header className="topbar"><div><span className="mobile-brand">MR</span><p>{active === "home" ? "PRODUCTION DESK" : `STAGE ${STAGES.findIndex((stage) => stage.id === active)}`}</p><strong>{STAGES.find((stage) => stage.id === active)?.label}</strong></div><div className="topbar-right"><span className={`risk-badge ${copyrightResult?.risk?.toLowerCase() || "neutral"}`}><ShieldAlert size={14} /> {copyrightResult ? `${copyrightResult.risk} risk` : "Risk unchecked"}</span><button className="top-project" onClick={() => setActive("project")}><Save size={16} /> Project</button></div></header>
        <div className="content-scroll">{mainContent()}</div>
      </section>
      <nav className="mobile-nav">{STAGES.slice(0, 10).map((stage) => { const Icon = stage.icon; return <button key={stage.id} className={active === stage.id ? "active" : ""} onClick={() => setActive(stage.id)}><Icon size={17} /><span>{stage.number || "Home"}</span></button>; })}</nav>
    </main>
  );
}

function Metric({ icon: Icon, title, value, detail, tone }: { icon: typeof Film; title: string; value: string; detail: string; tone: "good" | "risk" | "neutral" }) {
  return <div className={`metric-card ${tone}`}><div className="metric-icon"><Icon size={18} /></div><div><span>{title}</span><strong>{value}</strong><small>{detail}</small></div></div>;
}

function CaptionPreview({ options }: { options: Options }) {
  const style = { color: options.subtitleColor, fontSize: `${Math.min(options.subtitleSize, 38)}px` };
  return <div className={`caption-preview ${options.subtitlePosition}`}><div className="preview-grain" /><span style={style}>ဒီဇာတ်လမ်းကတော့ အစကနေ စိတ်ဝင်စားစရာကောင်းနေပါတယ်။</span><small>LAYOUT GUIDE · FINAL STYLE RENDERS IN FFMPEG</small></div>;
}

function RangeControl({ label, value, min, max, onChange, suffix = "" }: { label: string; value: number; min: number; max: number; onChange: (value: number) => void; suffix?: string }) {
  return <div className="range-control"><div><span>{label}</span><b>{value}{suffix}</b></div><input type="range" min={min} max={max} value={value} onChange={(event) => onChange(Number(event.target.value))} /></div>;
}

function BlurGuide({ options }: { options: Options }) {
  const style = { left: `${options.blurX}%`, top: `${options.blurY}%`, width: `${Math.min(options.blurWidth, 100 - options.blurX)}%`, height: `${Math.min(options.blurHeight, 100 - options.blurY)}%`, filter: `blur(${Math.min(options.blurStrength / 5, 8)}px)` };
  return <div className="blur-guide"><div className="guide-scene"><div className="guide-light one" /><div className="guide-light two" /><div className={`blur-region ${options.blurOriginalSubtitles ? "on" : ""}`} style={style}><span>Original subtitle zone</span></div></div><p>{options.blurOriginalSubtitles ? "Selection guide only. The boxblur is applied by FFmpeg during export." : "Enable blur to define the region FFmpeg will process."}</p></div>;
}

function RiskCard({ result }: { result: CopyrightResult | null }) {
  if (!result) return <aside className="risk-card empty"><ShieldAlert size={28} /><h2>Risk check pending</h2><p>Record source and permission facts, then run the checker before export.</p></aside>;
  return <aside className={`risk-card ${result.risk.toLowerCase()}`}><div className="risk-card-top"><span>ASSESSMENT</span><strong>{result.risk} risk</strong></div><p>{result.disclaimer}</p><ul>{result.reasons.map((reason) => <li key={reason}>{reason}</li>)}</ul><div className="attribution"><small>Suggested attribution</small><span>{result.attributionText}</span></div>{result.highRiskExportWarning ? <div className="high-risk-copy"><AlertTriangle size={16} /> High-risk export needs an explicit acknowledgement.</div> : null}</aside>;
}

function ReviewLine({ done, label, value }: { done: boolean; label: string; value: string }) {
  return <div className="review-line"><span className={done ? "done-dot" : "empty-dot"}>{done ? <BadgeCheck size={15} /> : <i />}</span><div><strong>{label}</strong><small>{value}</small></div></div>;
}

function JobCard({ job, onCancel, cancelling }: { job: Job | null; onCancel: () => void; cancelling: boolean }) {
  if (!job) return <aside className="job-card empty"><Clapperboard size={30} /><h2>Nothing is rendering yet</h2><p>Choose a movie and narration audio, then start a job. The server will return the actual job ID here.</p></aside>;
  const terminal = ["completed", "failed", "cancelled"].includes(job.status);
  return <aside className={`job-card ${job.status}`}><div className="job-title"><span><i className={job.status === "processing" ? "pulsing" : ""} /> JOB {job.jobId.slice(-8)}</span><b>{job.status}</b></div><h2>{job.message}</h2><div className="progress-track"><i style={{ width: `${job.progress}%` }} /></div><div className="job-meta"><span>{job.progress.toFixed(1)}%</span><span>{job.status === "processing" ? "FFmpeg elapsed-time progress" : terminal ? "Terminal state" : "Waiting for worker"}</span></div>{job.error ? <p className="job-error">{job.error}</p> : null}{job.outputUrl ? <a className="primary-button full-button" href={job.outputUrl}><Download size={18} /> Download final MP4</a> : null}{!terminal ? <button className="secondary-button full-button cancel-job" disabled={cancelling} onClick={onCancel}>{cancelling ? <LoaderCircle className="spin" size={17} /> : <X size={17} />}Cancel rendering</button> : null}</aside>;
}

function Capability({ label, enabled, detail }: { label: string; enabled: boolean; detail: string }) {
  return <div className="capability"><span className={enabled ? "cap-on" : "cap-off"}>{enabled ? <BadgeCheck size={17} /> : <AlertTriangle size={17} />}</span><div><strong>{label}</strong><small>{detail}</small></div><b>{enabled ? "Ready" : "Not configured"}</b></div>;
}

function HelpItem({ number, title, text }: { number: string; title: string; text: string }) {
  return <div className="help-item"><b>{number}</b><div><h2>{title}</h2><p>{text}</p></div></div>;
}
