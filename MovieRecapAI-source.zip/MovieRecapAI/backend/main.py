from __future__ import annotations

import asyncio
import contextlib
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, cast
from urllib.parse import unquote, urlparse

import httpx
from fastapi import Cookie, Depends, FastAPI, File, Form, HTTPException, Request, Response, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from itsdangerous import BadSignature, URLSafeSerializer
from pydantic import BaseModel, Field, field_validator

try:
    import pymysql
    from pymysql.cursors import DictCursor
except ImportError:  # Docker and local requirements install this; keeps module error intelligible.
    pymysql = None
    DictCursor = None

try:
    import yt_dlp  # type: ignore[import-not-found]
except ImportError:
    yt_dlp = None

APP_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = Path(os.getenv("MOVIERECAP_DATA_DIR", APP_ROOT / "data")).resolve()
UPLOAD_ROOT = DATA_ROOT / "uploads"
OUTPUT_ROOT = DATA_ROOT / "outputs"
TMP_ROOT = DATA_ROOT / "tmp"
DIST_ROOT = APP_ROOT / "dist" / "public"
MAX_FILE_BYTES = int(os.getenv("MAX_FILE_BYTES", str(2 * 1024 * 1024 * 1024)))
PUBLIC_CREDITS = int(os.getenv("PUBLIC_CREDITS", "3"))
OWNER_MODE_DEFAULT = os.getenv("OWNER_MODE_DEFAULT", "true").lower() not in {"0", "false", "no"}
SESSION_COOKIE = "mra_session"
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "true").lower() not in {"0", "false", "no"}
SESSION_SECRET = os.getenv("SESSION_SECRET", "development-only-change-me")
if os.getenv("APP_ENV", "development") == "production" and SESSION_SECRET == "development-only-change-me":
    raise RuntimeError("SESSION_SECRET must be configured in the production server environment.")
SERIALIZER = URLSafeSerializer(SESSION_SECRET, salt="movierecap-session-v1")
FFMPEG_AVAILABLE = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))
RUNNING_PROCESSES: dict[str, asyncio.subprocess.Process] = {}

for directory in (DATA_ROOT, UPLOAD_ROOT, OUTPUT_ROOT, TMP_ROOT):
    directory.mkdir(parents=True, exist_ok=True)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_name(name: str, fallback: str = "upload") -> str:
    base = Path(name or fallback).name
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "-", base).strip(".-")
    return cleaned[:120] or fallback


def media_extension(name: str) -> str:
    return Path(name).suffix.lower()


def seconds_from_timecode(value: str) -> float:
    match = re.fullmatch(r"(\d{2}):(\d{2}):(\d{2})[,.](\d{3})", value.strip())
    if not match:
        raise ValueError(f"Invalid SRT timecode: {value}")
    hours, minutes, seconds, milliseconds = map(int, match.groups())
    return hours * 3600 + minutes * 60 + seconds + milliseconds / 1000


def format_srt_time(seconds: float) -> str:
    milliseconds = max(0, int(round(seconds * 1000)))
    hours, milliseconds = divmod(milliseconds, 3_600_000)
    minutes, milliseconds = divmod(milliseconds, 60_000)
    whole_seconds, milliseconds = divmod(milliseconds, 1000)
    return f"{hours:02}:{minutes:02}:{whole_seconds:02},{milliseconds:03}"


def parse_srt_text(source: str) -> list[dict[str, Any]]:
    """Strict enough for real validation, tolerant of UTF-8/CRLF/omitted cue indices."""
    normalized = source.replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")
    blocks = [block.strip() for block in re.split(r"\n\s*\n", normalized) if block.strip()]
    cues: list[dict[str, Any]] = []
    timeline_pattern = re.compile(
        r"^(?P<start>\d{2}:\d{2}:\d{2}[,.]\d{3})\s+-->\s+(?P<end>\d{2}:\d{2}:\d{2}[,.]\d{3})(?:\s+.*)?$"
    )
    for block in blocks:
        lines = [line.strip() for line in block.split("\n")]
        timeline_index = 1 if lines and re.fullmatch(r"\d+", lines[0]) else 0
        if timeline_index >= len(lines):
            continue
        match = timeline_pattern.match(lines[timeline_index])
        if not match:
            continue
        text = " ".join(line for line in lines[timeline_index + 1 :] if line).strip()
        if not text:
            continue
        start = seconds_from_timecode(match.group("start"))
        end = seconds_from_timecode(match.group("end"))
        if end <= start:
            raise ValueError("An SRT cue ends before it begins.")
        cues.append(
            {
                "index": len(cues) + 1,
                "start": start,
                "end": end,
                "startTime": format_srt_time(start),
                "endTime": format_srt_time(end),
                "text": text,
            }
        )
    if not cues:
        raise ValueError("No valid SRT subtitle cues were found.")
    return cues


def decode_srt(raw: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-16", "cp1252"):
        with contextlib.suppress(UnicodeDecodeError):
            return raw.decode(encoding)
    raise ValueError("The subtitle file is not valid UTF-8, UTF-16 or Windows-1252 text.")


def cue_text(cues: list[dict[str, Any]], limit: int = 85_000) -> str:
    merged = "\n".join(f"[{cue['startTime']}–{cue['endTime']}] {cue['text']}" for cue in cues)
    return merged[:limit]


def split_scenes(cues: list[dict[str, Any]], max_cues: int = 40, pause_seconds: float = 3.0) -> list[dict[str, Any]]:
    scenes: list[dict[str, Any]] = []
    current: list[dict[str, Any]] = []
    for cue in cues:
        if current and (len(current) >= max_cues or cue["start"] - current[-1]["end"] >= pause_seconds):
            scenes.append({"start": current[0]["start"], "end": current[-1]["end"], "cueCount": len(current), "text": " ".join(item["text"] for item in current)})
            current = []
        current.append(cue)
    if current:
        scenes.append({"start": current[0]["start"], "end": current[-1]["end"], "cueCount": len(current), "text": " ".join(item["text"] for item in current)})
    for index, scene in enumerate(scenes, 1):
        scene["index"] = index
        scene["estimatedWords"] = max(18, round(len(scene["text"].split()) * 0.72))
    return scenes


def sentence_spans(text: str) -> list[str]:
    clean = re.sub(r"\s+", " ", text).strip()
    return [part.strip() for part in re.split(r"(?<=[.!?။！？])\s+", clean) if part.strip()] or ([clean] if clean else [])


def timed_srt(text: str, duration: float) -> str:
    sentences = sentence_spans(text)
    if not sentences:
        raise ValueError("No narration sentences were found.")
    weights = [max(1, len(sentence.split())) for sentence in sentences]
    total = sum(weights)
    cursor = 0.0
    blocks: list[str] = []
    for index, (sentence, weight) in enumerate(zip(sentences, weights), 1):
        end = duration if index == len(sentences) else min(duration, cursor + duration * weight / total)
        blocks.append(f"{index}\n{format_srt_time(cursor)} --> {format_srt_time(end)}\n{sentence}\n")
        cursor = end
    return "\n".join(blocks)


def probe_media(path: Path) -> dict[str, Any]:
    if not FFMPEG_AVAILABLE:
        raise RuntimeError("FFmpeg and FFprobe are required but were not found on this server.")
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,width,height", "-of", "json", str(path)],
        capture_output=True,
        text=True,
        check=False,
        timeout=45,
    )
    if result.returncode != 0:
        raise ValueError("FFprobe could not read this media file.")
    payload = json.loads(result.stdout or "{}")
    duration = float(payload.get("format", {}).get("duration") or 0)
    streams = payload.get("streams", [])
    video = next((stream for stream in streams if stream.get("codec_type") == "video"), {})
    return {
        "duration": round(duration, 3),
        "width": video.get("width"),
        "height": video.get("height"),
        "hasAudio": any(stream.get("codec_type") == "audio" for stream in streams),
    }


class Store:
    """Small server-side persistence layer: managed MySQL when DATABASE_URL is available, SQLite for local tests."""

    def __init__(self) -> None:
        self.database_url = os.getenv("DATABASE_URL", "")
        self.is_mysql = self.database_url.startswith(("mysql://", "mysql+pymysql://")) and pymysql is not None
        self.sqlite_path = DATA_ROOT / "movierecap.db"
        self._initialize()

    def _connect(self):
        if self.is_mysql:
            parsed = urlparse(self.database_url.replace("mysql+pymysql://", "mysql://", 1))
            driver = cast(Any, pymysql)
            cursor_type = cast(Any, DictCursor)
            return driver.connect(
                host=parsed.hostname,
                port=parsed.port or 3306,
                user=unquote(parsed.username or ""),
                password=unquote(parsed.password or ""),
                database=(parsed.path or "/").lstrip("/"),
                charset="utf8mb4",
                cursorclass=cursor_type,
                autocommit=True,
            )
        conn = sqlite3.connect(self.sqlite_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _sql(self, query: str) -> str:
        return query.replace("?", "%s") if self.is_mysql else query

    def execute(self, query: str, params: tuple[Any, ...] = ()) -> int:
        connection = self._connect()
        try:
            cursor = connection.cursor()
            try:
                cursor.execute(self._sql(query), params)
                affected = int(cursor.rowcount)
            finally:
                cursor.close()
            if not self.is_mysql:
                connection.commit()
            return affected
        finally:
            connection.close()

    def fetchone(self, query: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
        connection = self._connect()
        try:
            cursor = connection.cursor()
            try:
                cursor.execute(self._sql(query), params)
                row = cursor.fetchone()
            finally:
                cursor.close()
            return dict(row) if row else None
        finally:
            connection.close()

    def _initialize(self) -> None:
        auto_increment = "BIGINT AUTO_INCREMENT PRIMARY KEY" if self.is_mysql else "INTEGER PRIMARY KEY AUTOINCREMENT"
        self.execute(
            f"""CREATE TABLE IF NOT EXISTS mra_assets (
                internal_id {auto_increment}, asset_id VARCHAR(64) UNIQUE NOT NULL, owner_id VARCHAR(64) NOT NULL,
                kind VARCHAR(20) NOT NULL, original_name VARCHAR(255) NOT NULL, stored_path TEXT NOT NULL,
                content_type VARCHAR(160), size_bytes BIGINT NOT NULL, metadata_json TEXT NOT NULL, created_at VARCHAR(40) NOT NULL
            )"""
        )
        self.execute(
            f"""CREATE TABLE IF NOT EXISTS mra_jobs (
                internal_id {auto_increment}, job_id VARCHAR(64) UNIQUE NOT NULL, owner_id VARCHAR(64) NOT NULL,
                status VARCHAR(24) NOT NULL, progress DOUBLE NOT NULL, message TEXT NOT NULL, output_name VARCHAR(255),
                error_text TEXT, payload_json TEXT NOT NULL, credit_cost INT NOT NULL DEFAULT 0, credit_refunded INT NOT NULL DEFAULT 0,
                created_at VARCHAR(40) NOT NULL, updated_at VARCHAR(40) NOT NULL
            )"""
        )
        self.execute(
            """CREATE TABLE IF NOT EXISTS mra_credits (
                subject_id VARCHAR(64) PRIMARY KEY, balance INT NOT NULL, is_admin INT NOT NULL DEFAULT 0, created_at VARCHAR(40) NOT NULL, updated_at VARCHAR(40) NOT NULL
            )"""
        )
        # Existing development databases can predate the render-refund fields.
        for statement in (
            "ALTER TABLE mra_jobs ADD COLUMN credit_cost INT NOT NULL DEFAULT 0",
            "ALTER TABLE mra_jobs ADD COLUMN credit_refunded INT NOT NULL DEFAULT 0",
        ):
            try:
                self.execute(statement)
            except Exception as error:
                if "duplicate column" not in str(error).lower():
                    raise

    def ensure_credit_account(self, subject_id: str) -> None:
        exists = self.fetchone("SELECT subject_id FROM mra_credits WHERE subject_id = ?", (subject_id,))
        if not exists:
            timestamp = now_iso()
            self.execute(
                "INSERT INTO mra_credits (subject_id, balance, is_admin, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (subject_id, PUBLIC_CREDITS, 1 if OWNER_MODE_DEFAULT else 0, timestamp, timestamp),
            )
        elif OWNER_MODE_DEFAULT:
            self.execute("UPDATE mra_credits SET is_admin = 1, updated_at = ? WHERE subject_id = ?", (now_iso(), subject_id))

    def credit_state(self, subject_id: str) -> dict[str, Any]:
        self.ensure_credit_account(subject_id)
        state = self.fetchone("SELECT balance, is_admin FROM mra_credits WHERE subject_id = ?", (subject_id,))
        assert state is not None
        return {"credits": "Unlimited" if state["is_admin"] else int(state["balance"]), "isAdmin": bool(state["is_admin"])}

    def unlock_admin(self, subject_id: str) -> None:
        self.ensure_credit_account(subject_id)
        self.execute("UPDATE mra_credits SET is_admin = ?, updated_at = ? WHERE subject_id = ?", (1, now_iso(), subject_id))

    def consume_credits(self, subject_id: str, amount: int, purpose: str) -> dict[str, Any]:
        state = self.credit_state(subject_id)
        if state["isAdmin"]:
            return {**state, "charged": 0, "purpose": purpose}
        changed = self.execute(
            "UPDATE mra_credits SET balance = balance - ?, updated_at = ? WHERE subject_id = ? AND is_admin = ? AND balance >= ?",
            (amount, now_iso(), subject_id, 0, amount),
        )
        if changed != 1:
            latest = self.credit_state(subject_id)
            if latest["isAdmin"]:
                return {**latest, "charged": 0, "purpose": purpose}
            raise HTTPException(status_code=402, detail=f"Not enough credits for {purpose}. This action needs {amount} credit(s); {latest['credits']} remain.")
        latest = self.credit_state(subject_id)
        return {"credits": latest["credits"], "isAdmin": False, "charged": amount, "purpose": purpose}

    def refund_credits(self, subject_id: str, amount: int) -> None:
        state = self.credit_state(subject_id)
        if not state["isAdmin"]:
            self.execute("UPDATE mra_credits SET balance = balance + ?, updated_at = ? WHERE subject_id = ?", (amount, now_iso(), subject_id))

    def create_asset(self, asset: dict[str, Any]) -> None:
        self.execute(
            """INSERT INTO mra_assets (asset_id, owner_id, kind, original_name, stored_path, content_type, size_bytes, metadata_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                asset["assetId"], asset["ownerId"], asset["kind"], asset["originalName"], asset["storedPath"], asset.get("contentType"),
                asset["sizeBytes"], json.dumps(asset.get("metadata", {}), ensure_ascii=False), asset["createdAt"],
            ),
        )

    def get_asset(self, asset_id: str, owner_id: str | None = None) -> dict[str, Any] | None:
        query = "SELECT * FROM mra_assets WHERE asset_id = ?"
        params: tuple[Any, ...] = (asset_id,)
        if owner_id:
            query += " AND owner_id = ?"
            params += (owner_id,)
        asset = self.fetchone(query, params)
        if asset:
            asset["metadata"] = json.loads(asset.pop("metadata_json") or "{}")
            asset["assetId"] = asset.pop("asset_id")
            asset["ownerId"] = asset.pop("owner_id")
            asset["originalName"] = asset.pop("original_name")
            asset["storedPath"] = asset.pop("stored_path")
            asset["sizeBytes"] = asset.pop("size_bytes")
            asset["contentType"] = asset.pop("content_type")
            asset["createdAt"] = asset.pop("created_at")
        return asset

    def create_job(self, job: dict[str, Any]) -> None:
        self.execute(
            """INSERT INTO mra_jobs (job_id, owner_id, status, progress, message, output_name, error_text, payload_json, credit_cost, credit_refunded, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (job["jobId"], job["ownerId"], job["status"], job["progress"], job["message"], None, None, json.dumps(job["payload"], ensure_ascii=False), job["creditCost"], 0, job["createdAt"], job["updatedAt"]),
        )

    def get_job(self, job_id: str, owner_id: str | None = None) -> dict[str, Any] | None:
        query = "SELECT * FROM mra_jobs WHERE job_id = ?"
        params: tuple[Any, ...] = (job_id,)
        if owner_id:
            query += " AND owner_id = ?"
            params += (owner_id,)
        job = self.fetchone(query, params)
        if job:
            job["jobId"] = job.pop("job_id")
            job["ownerId"] = job.pop("owner_id")
            job["outputName"] = job.pop("output_name")
            job["error"] = job.pop("error_text")
            job["creditCost"] = job.pop("credit_cost")
            job["creditRefunded"] = bool(job.pop("credit_refunded"))
            job["payload"] = json.loads(job.pop("payload_json") or "{}")
            job["createdAt"] = job.pop("created_at")
            job["updatedAt"] = job.pop("updated_at")
        return job

    def update_job(self, job_id: str, **changes: Any) -> None:
        column_map = {"status": "status", "progress": "progress", "message": "message", "outputName": "output_name", "error": "error_text"}
        updates: list[str] = []
        values: list[Any] = []
        for key, value in changes.items():
            if key in column_map:
                updates.append(f"{column_map[key]} = ?")
                values.append(value)
        updates.append("updated_at = ?")
        values.extend([now_iso(), job_id])
        self.execute(f"UPDATE mra_jobs SET {', '.join(updates)} WHERE job_id = ?", tuple(values))

    def refund_job_once(self, job_id: str) -> bool:
        job = self.get_job(job_id)
        if not job or job["creditCost"] <= 0 or job["creditRefunded"]:
            return False
        changed = self.execute(
            "UPDATE mra_jobs SET credit_refunded = ?, updated_at = ? WHERE job_id = ? AND credit_refunded = ?",
            (1, now_iso(), job_id, 0),
        )
        if changed != 1:
            return False
        self.refund_credits(job["ownerId"], int(job["creditCost"]))
        return True

    def get_job_by_output(self, output_name: str, owner_id: str) -> dict[str, Any] | None:
        return self.get_job_by_field("output_name", output_name, owner_id)

    def get_job_by_field(self, field: str, value: str, owner_id: str) -> dict[str, Any] | None:
        if field != "output_name":
            raise ValueError("Unsupported job lookup field")
        query = "SELECT * FROM mra_jobs WHERE output_name = ? AND owner_id = ?"
        row = self.fetchone(query, (value, owner_id))
        if not row:
            return None
        return self.get_job(row["job_id"], owner_id)


STORE = Store()


class UserContext(BaseModel):
    subject_id: str


def subject_from_cookie(cookie_value: str | None) -> str | None:
    if not cookie_value:
        return None
    try:
        payload = SERIALIZER.loads(cookie_value)
        subject = payload.get("sub") if isinstance(payload, dict) else None
        return subject if isinstance(subject, str) and re.fullmatch(r"[a-f0-9-]{36}", subject) else None
    except BadSignature:
        return None


def ensure_user(response: Response, mra_session: str | None = Cookie(default=None)) -> UserContext:
    subject_id = subject_from_cookie(mra_session)
    if not subject_id:
        subject_id = str(uuid.uuid4())
        token = SERIALIZER.dumps({"sub": subject_id, "v": 1})
        response.set_cookie(
            SESSION_COOKIE,
            token,
            httponly=True,
            secure=COOKIE_SECURE,
            samesite="none" if COOKIE_SECURE else "lax",
            max_age=60 * 60 * 24 * 30,
            path="/",
        )
    STORE.ensure_credit_account(subject_id)
    return UserContext(subject_id=subject_id)


def owned_asset(asset_id: str, user: UserContext, expected_kind: str | None = None) -> dict[str, Any]:
    asset = STORE.get_asset(asset_id, user.subject_id)
    if not asset:
        raise HTTPException(status_code=404, detail="The requested upload was not found for this session.")
    if expected_kind and asset["kind"] != expected_kind:
        raise HTTPException(status_code=422, detail=f"Expected a {expected_kind} upload, not {asset['kind']}.")
    path = Path(asset["storedPath"])
    if not path.is_file():
        raise HTTPException(status_code=410, detail="The uploaded file is no longer available on this server.")
    return asset


async def write_upload(upload: UploadFile, kind: Literal["movie", "srt", "audio", "logo"], user: UserContext) -> dict[str, Any]:
    allowed: dict[str, set[str]] = {
        "movie": {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"},
        "srt": {".srt", ".txt"},
        "audio": {".mp3", ".wav", ".m4a", ".aac", ".ogg"},
        "logo": {".png", ".jpg", ".jpeg", ".webp"},
    }
    if not upload.filename:
        raise HTTPException(status_code=422, detail="No file was selected. Choose a supported file and try again.")
    extension = media_extension(upload.filename)
    if extension not in allowed[kind]:
        raise HTTPException(status_code=415, detail=f"Unsupported {kind} format. Allowed: {', '.join(sorted(allowed[kind]))}.")
    asset_id = f"ast_{uuid.uuid4().hex}"
    destination = UPLOAD_ROOT / f"{asset_id}_{safe_name(upload.filename)}"
    byte_count = 0
    digest = hashlib.sha256()
    try:
        with destination.open("wb") as target:
            while chunk := await upload.read(1024 * 1024):
                byte_count += len(chunk)
                if byte_count > MAX_FILE_BYTES:
                    raise HTTPException(status_code=413, detail=f"File is too large. Maximum upload size is {MAX_FILE_BYTES // (1024 * 1024)} MB.")
                digest.update(chunk)
                target.write(chunk)
    except HTTPException:
        destination.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()
    if byte_count == 0:
        destination.unlink(missing_ok=True)
        raise HTTPException(status_code=422, detail="The selected file is empty.")

    metadata: dict[str, Any] = {"sha256": digest.hexdigest()}
    if kind == "srt":
        try:
            cues = parse_srt_text(decode_srt(destination.read_bytes()))
        except ValueError as error:
            destination.unlink(missing_ok=True)
            raise HTTPException(status_code=422, detail=str(error)) from error
        metadata.update({"cues": cues, "cueCount": len(cues), "duration": cues[-1]["end"]})
    elif kind in {"movie", "audio"}:
        try:
            metadata.update(probe_media(destination))
        except (RuntimeError, ValueError) as error:
            destination.unlink(missing_ok=True)
            raise HTTPException(status_code=422, detail=str(error)) from error

    asset = {
        "assetId": asset_id,
        "ownerId": user.subject_id,
        "kind": kind,
        "originalName": safe_name(upload.filename),
        "storedPath": str(destination),
        "contentType": upload.content_type or "application/octet-stream",
        "sizeBytes": byte_count,
        "metadata": metadata,
        "createdAt": now_iso(),
    }
    STORE.create_asset(asset)
    return public_asset(asset)


def public_asset(asset: dict[str, Any]) -> dict[str, Any]:
    return {
        "assetId": asset["assetId"],
        "kind": asset["kind"],
        "name": asset["originalName"],
        "sizeBytes": asset["sizeBytes"],
        "metadata": asset["metadata"],
        "createdAt": asset["createdAt"],
    }


def ai_provider() -> tuple[str, str, str] | None:
    if os.getenv("MANUS_API_URL") and os.getenv("MANUS_API_KEY"):
        return os.getenv("MANUS_API_URL", "").rstrip("/") + "/v1", os.getenv("MANUS_API_KEY", ""), os.getenv("AI_MODEL", "")
    if os.getenv("OPENAI_API_KEY"):
        return os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/"), os.getenv("OPENAI_API_KEY", ""), os.getenv("AI_MODEL", "")
    return None


async def call_recap_ai(cues: list[dict[str, Any]], language: str, target_seconds: float, narrator_mode: str) -> str:
    provider = ai_provider()
    if not provider:
        raise HTTPException(status_code=503, detail="AI recap is not configured. Add a server-side MANUS_API_KEY or OPENAI_API_KEY; do not put the key in the app.")
    base_url, api_key, configured_model = provider
    target_minutes = max(1, round(target_seconds / 60))
    system_prompt = (
        "You are MovieRecap AI's professional recap narrator. Write exactly one coherent spoken movie-recap narration, not a screenplay. "
        "Never write character-by-character dialogue, speaker labels, or storybook-style prose. Keep facts grounded in the supplied subtitle timeline; do not invent scenes. "
        "Use narrative transitions and a natural spoken rhythm. Return only narration text, no title, outline, markdown, notes, or safety claims."
    )
    language_instruction = {
        "Burmese": "Write natural spoken Burmese. Prefer ကျနော်, သူဒို့ and မိတ်ဆွေဒို့ where they fit. Avoid stiff textbook Burmese.",
        "English": "Write natural spoken English.",
        "Chinese": "Write natural spoken Chinese.",
        "Japanese": "Write natural spoken Japanese.",
        "Korean": "Write natural spoken Korean.",
        "Thai": "Write natural spoken Thai.",
        "Spanish": "Write natural spoken Spanish.",
        "French": "Write natural spoken French.",
    }.get(language, "Write in the requested language naturally.")
    user_prompt = (
        f"Narration language: {language}. {language_instruction}\n"
        f"Target source duration: approximately {target_seconds:.0f} seconds ({target_minutes} minute(s)). "
        f"Write a dense recap suitable for about that duration at normal narration speed. Narration mode: {narrator_mode}.\n\n"
        f"Subtitle timeline:\n{cue_text(cues)}"
    )
    body = {
        "model": configured_model or "gpt-4o-mini",
        "messages": [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}],
        "temperature": 0.6,
    }
    async with httpx.AsyncClient(timeout=90) as client:
        response = await client.post(
            f"{base_url}/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=body,
        )
    if response.status_code >= 400:
        detail = response.text[:500]
        raise HTTPException(status_code=502, detail=f"AI recap provider rejected the request ({response.status_code}): {detail}")
    payload = response.json()
    if payload.get("error"):
        raise HTTPException(status_code=502, detail=f"AI recap provider error: {payload['error']}")
    choices = payload.get("choices") or []
    text = choices[0].get("message", {}).get("content", "").strip() if choices else ""
    if not text:
        raise HTTPException(status_code=502, detail="AI recap provider returned no narration text. No credits were kept for this failed request.")
    return text


async def translate_srt_cues(cues: list[dict[str, Any]], target_language: str) -> list[dict[str, Any]]:
    provider = ai_provider()
    if not provider:
        raise HTTPException(status_code=503, detail="SRT translation is not configured. Add a server-side AI credential first.")
    base_url, api_key, configured_model = provider
    translated: list[dict[str, Any]] = []
    for offset in range(0, len(cues), 30):
        batch = cues[offset : offset + 30]
        numbered = json.dumps([{"i": index + 1, "text": cue["text"]} for index, cue in enumerate(batch)], ensure_ascii=False)
        body = {
            "model": configured_model or "gpt-4o-mini",
            "messages": [
                {"role": "system", "content": "Translate subtitle text faithfully. Keep names, numbers and meaning. Return only a JSON array of objects with keys i and text, in the same order. Do not add commentary."},
                {"role": "user", "content": f"Translate these subtitle lines into natural spoken {target_language}. Preserve short subtitle-friendly phrasing.\n{numbered}"},
            ],
            "temperature": 0.2,
        }
        async with httpx.AsyncClient(timeout=180) as client:
            response = await client.post(f"{base_url}/chat/completions", headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}, json=body)
        if response.status_code >= 400:
            raise HTTPException(status_code=502, detail=f"SRT translation provider rejected the request ({response.status_code}).")
        choices = response.json().get("choices") or []
        raw = choices[0].get("message", {}).get("content", "") if choices else ""
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip())
        try:
            items = json.loads(raw)
            by_index = {int(item["i"]): str(item["text"]).strip() for item in items}
        except (ValueError, TypeError, KeyError, json.JSONDecodeError) as error:
            raise HTTPException(status_code=502, detail="The translation provider returned an invalid subtitle list.") from error
        if len(by_index) != len(batch) or any(not by_index.get(index + 1) for index in range(len(batch))):
            raise HTTPException(status_code=502, detail="The translation provider returned an incomplete subtitle list.")
        translated.extend({**cue, "text": by_index[index + 1]} for index, cue in enumerate(batch))
    return translated


async def transcribe_movie_audio(movie_path: Path) -> list[dict[str, Any]]:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="Audio translation needs a server-side OPENAI_API_KEY.")

    base = os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
    model = os.getenv("STT_MODEL", "whisper-1")
    try:
        chunk_seconds = int(os.getenv("STT_CHUNK_SECONDS", "480"))
    except ValueError:
        chunk_seconds = 480
    chunk_seconds = max(60, min(chunk_seconds, 600))

    duration_probe = await asyncio.create_subprocess_exec(
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(movie_path),
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
    )
    duration_stdout, duration_stderr = await duration_probe.communicate()
    if duration_probe.returncode != 0:
        raise HTTPException(status_code=422, detail=f"Could not inspect the video audio: {duration_stderr.decode(errors='ignore')[-500:]}")
    try:
        duration = float(duration_stdout.decode().strip())
    except ValueError as error:
        raise HTTPException(status_code=422, detail="Could not determine the video duration.") from error
    if duration <= 0:
        raise HTTPException(status_code=422, detail="The uploaded video has no usable duration.")

    all_cues: list[dict[str, Any]] = []
    chunk_index = 0
    start_seconds = 0.0
    timeout = httpx.Timeout(900.0, connect=30.0)

    async with httpx.AsyncClient(timeout=timeout) as client:
        while start_seconds < duration:
            chunk_index += 1
            chunk_start = start_seconds
            chunk_length = min(float(chunk_seconds), duration - chunk_start)
            audio_path = TMP_ROOT / f"transcribe-{uuid.uuid4().hex}-{chunk_index}.wav"
            try:
                process = await asyncio.create_subprocess_exec(
                    "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                    "-ss", f"{chunk_start:.3f}", "-t", f"{chunk_length:.3f}",
                    "-i", str(movie_path), "-vn", "-ac", "1", "-ar", "16000",
                    "-c:a", "pcm_s16le", str(audio_path),
                    stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await process.communicate()
                if process.returncode != 0 or not audio_path.is_file() or audio_path.stat().st_size == 0:
                    detail = stderr.decode(errors="ignore").strip()[-500:]
                    raise HTTPException(status_code=422, detail=f"Could not extract audio chunk {chunk_index}: {detail}")

                with audio_path.open("rb") as audio_file:
                    response = await client.post(
                        f"{base}/audio/transcriptions",
                        headers={"Authorization": f"Bearer {api_key}"},
                        data={
                            "model": model,
                            "response_format": "verbose_json",
                            "timestamp_granularities[]": "segment",
                        },
                        files={"file": (f"audio-{chunk_index}.wav", audio_file, "audio/wav")},
                    )
                if response.status_code >= 400:
                    body = response.text.strip().replace("\n", " ")[:500]
                    raise HTTPException(
                        status_code=502,
                        detail=f"Speech-to-text provider rejected chunk {chunk_index} ({response.status_code}): {body}",
                    )
                try:
                    payload = response.json()
                except ValueError as error:
                    raise HTTPException(status_code=502, detail=f"Speech-to-text provider returned invalid JSON for chunk {chunk_index}.") from error

                for segment in payload.get("segments") or []:
                    try:
                        local_start = float(segment.get("start", 0))
                        local_end = float(segment.get("end", 0))
                    except (TypeError, ValueError):
                        continue
                    text = str(segment.get("text", "")).strip()
                    start = max(0.0, chunk_start + local_start)
                    end = min(duration, chunk_start + local_end)
                    if text and end > start:
                        all_cues.append({
                            "index": len(all_cues) + 1,
                            "start": start,
                            "end": end,
                            "startTime": format_srt_time(start),
                            "endTime": format_srt_time(end),
                            "text": text,
                        })
            except httpx.HTTPError as error:
                raise HTTPException(status_code=502, detail=f"Speech-to-text provider request failed on chunk {chunk_index}: {error}") from error
            finally:
                audio_path.unlink(missing_ok=True)

            start_seconds += chunk_length

    if not all_cues:
        raise HTTPException(status_code=422, detail="No speech segments were detected in the video audio.")

    # Remove accidental duplicate/overlapping segment starts while preserving order.
    all_cues.sort(key=lambda cue: (cue["start"], cue["end"]))
    cues: list[dict[str, Any]] = []
    for cue in all_cues:
        if cues and cue["start"] < cues[-1]["end"] and cue["text"] == cues[-1]["text"]:
            cues[-1]["end"] = max(cues[-1]["end"], cue["end"])
            cues[-1]["endTime"] = format_srt_time(cues[-1]["end"])
            continue
        cue["index"] = len(cues) + 1
        cues.append(cue)
    return cues


async def synthesize_tts(text: str, voice: str, voice_gender: str, style: str, speed: float, language: str) -> bytes:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="TTS is not configured. Add a server-side OPENAI_API_KEY or upload narration audio for rendering.")
    base = os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
    payload: dict[str, Any] = {
        "model": os.getenv("TTS_MODEL", "gpt-4o-mini-tts"),
        "voice": voice,
        "input": text,
        "response_format": "mp3",
        "speed": speed,
        "instructions": f"Narrate in {language} with a {style} movie recap tone. Prefer a {voice_gender} narrator presentation when the selected voice supports it. Keep the speech natural, single-narrator and clear.",
    }
    async with httpx.AsyncClient(timeout=180) as client:
        response = await client.post(
            f"{base}/audio/speech",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=payload,
        )
    if response.status_code >= 400:
        raise HTTPException(status_code=502, detail=f"TTS provider rejected the request ({response.status_code}): {response.text[:500]}")
    if not response.content:
        raise HTTPException(status_code=502, detail="TTS provider returned no audio bytes.")
    return response.content


class RecapRequest(BaseModel):
    srtId: str
    language: Literal["Burmese", "English", "Chinese", "Japanese", "Korean", "Thai", "Spanish", "French"] = "Burmese"
    narratorMode: Literal["single", "multi"] = "single"
    targetSeconds: float = Field(ge=1, le=4 * 60 * 60)


class ScenePlanRequest(BaseModel):
    srtId: str
    maxCuesPerScene: int = Field(default=40, ge=10, le=100)
    pauseSeconds: float = Field(default=3.0, ge=1, le=15)


class TimedSubtitleRequest(BaseModel):
    text: str = Field(min_length=1, max_length=120_000)
    durationSeconds: float = Field(gt=0, le=4 * 60 * 60)


class TranslateSubtitleRequest(BaseModel):
    srtId: str
    targetLanguage: Literal["Burmese", "English", "Chinese", "Japanese", "Korean", "Thai", "Spanish", "French"] = "Burmese"


class AudioTranslateRequest(BaseModel):
    movieId: str
    targetLanguage: Literal["Burmese", "English", "Chinese", "Japanese", "Korean", "Thai", "Spanish", "French"] = "Burmese"


class TtsRequest(BaseModel):
    text: str = Field(min_length=4, max_length=120_000)
    language: Literal["Burmese", "English", "Chinese", "Japanese", "Korean", "Thai", "Spanish", "French"] = "Burmese"
    voiceGender: Literal["Female", "Male"] = "Female"
    voice: Literal["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer", "verse"] = "nova"
    style: Literal["professional", "deep", "scary", "dark", "emotional", "sad", "happy", "action"] = "professional"
    speed: float = Field(default=1.0, ge=0.25, le=4.0)


class CopyrightRequest(BaseModel):
    sourcePlatform: Literal["YouTube", "Facebook", "TikTok", "Local upload", "Other"] = "Local upload"
    sourceUrl: str = ""
    creator: str = ""
    license: str = ""
    permission: str = ""
    attribution: str = ""
    isOriginal: bool = False
    willTransform: bool = True


class RenderOptions(BaseModel):
    includeOriginalAudio: bool = False
    subtitleColor: str = Field(default="#FFFFFF", pattern=r"^#[0-9A-Fa-f]{6}$")
    subtitleSize: int = Field(default=24, ge=12, le=72)
    subtitlePosition: Literal["bottom", "center", "top"] = "bottom"
    logoPosition: Literal["top-left", "top-right", "bottom-left", "bottom-right"] = "top-right"
    blurOriginalSubtitles: bool = False
    blurStrength: int = Field(default=12, ge=1, le=40)
    blurX: int = Field(default=0, ge=0, le=100)
    blurY: int = Field(default=78, ge=0, le=100)
    blurWidth: int = Field(default=100, ge=1, le=100)
    blurHeight: int = Field(default=22, ge=1, le=100)
    rotation: Literal["0", "90", "180", "270"] = "0"
    flipHorizontal: bool = False
    flipVertical: bool = False
    videoSpeed: float = Field(default=1.0, ge=0.5, le=2.0)
    quality: Literal["720p", "1080p", "source"] = "720p"


class RenderRequest(BaseModel):
    movieId: str
    srtId: str | None = None
    narrationSrtId: str | None = None
    audioId: str | None = None
    logoId: str | None = None
    filename: str = Field(default="movie-recap")
    options: RenderOptions = Field(default_factory=RenderOptions)
    copyright: CopyrightRequest = Field(default_factory=CopyrightRequest)
    highRiskAcknowledged: bool = False

    @field_validator("filename")
    @classmethod
    def filename_is_safe(cls, value: str) -> str:
        cleaned = re.sub(r"[^A-Za-z0-9_-]+", "-", value).strip("-")[:80]
        if not cleaned:
            raise ValueError("Use at least one letter or number for the output filename.")
        return cleaned


class AdminUnlockRequest(BaseModel):
    token: str = Field(min_length=1, max_length=512)


class SourceUrlRequest(BaseModel):
    url: str = Field(min_length=8, max_length=2048)

    @field_validator("url")
    @classmethod
    def validate_source_url(cls, value: str) -> str:
        parsed = urlparse(value.strip())
        host = (parsed.hostname or "").lower()
        allowed = ("youtube.com", "youtu.be", "tiktok.com", "douyin.com", "xiaohongshu.com", "rednote.com")
        if parsed.scheme not in {"http", "https"} or not any(host == domain or host.endswith(f".{domain}") for domain in allowed):
            raise ValueError("Only YouTube, TikTok, Douyin, Rednote or Xiaohongshu links are accepted.")
        return value.strip()


class CancelRequest(BaseModel):
    reason: str = Field(default="Cancelled by user", max_length=160)


def calculate_risk(input_: CopyrightRequest) -> dict[str, Any]:
    score = 0
    reasons: list[str] = []
    if input_.sourcePlatform in {"YouTube", "Facebook", "TikTok"}:
        score += 3
        reasons.append(f"{input_.sourcePlatform} content may be protected even when it is publicly visible.")
    if not input_.isOriginal:
        score += 3
        reasons.append("The source is not marked as an original work.")
    if not input_.permission.strip():
        score += 2
        reasons.append("No written permission or license evidence was provided.")
    if not input_.license.strip():
        score += 1
        reasons.append("No license terms were recorded.")
    if input_.willTransform:
        score += 1
        reasons.append("Recapping/transformation can reduce risk in some jurisdictions, but it does not automatically grant usage rights.")
    if input_.license.lower().strip() in {"cc by", "creative commons attribution", "public domain"} and input_.attribution.strip():
        score = max(0, score - 4)
        reasons.append("A reusable license plus attribution was supplied; verify the exact license scope independently.")
    if input_.permission.strip():
        score = max(0, score - 4)
        reasons.append("Permission was recorded; retain the underlying proof and verify its scope.")
    risk = "High" if score >= 7 else "Medium" if score >= 3 else "Low"
    attribution = input_.attribution.strip() or (f"Source: {input_.creator.strip()}" if input_.creator.strip() else "Add source/creator/license attribution before publication if applicable.")
    return {
        "risk": risk,
        "score": score,
        "reasons": reasons,
        "attributionText": attribution,
        "disclaimer": "This is a production risk indicator, not legal advice. No video can be guaranteed 100% copyright safe.",
        "highRiskExportWarning": risk == "High",
    }


def ass_color(hex_color: str) -> str:
    # ASS uses BBGGRR with alpha first; &H00 is opaque.
    red, green, blue = hex_color[1:3], hex_color[3:5], hex_color[5:7]
    return f"&H00{blue}{green}{red}"


def atempo_filter(speed: float) -> str:
    pieces: list[str] = []
    remaining = speed
    while remaining > 2:
        pieces.append("atempo=2")
        remaining /= 2
    while remaining < 0.5:
        pieces.append("atempo=0.5")
        remaining /= 0.5
    pieces.append(f"atempo={remaining:.5f}")
    return ",".join(pieces)


def style_filter(srt_path: Path, options: RenderOptions) -> str:
    alignment = {"bottom": 2, "center": 5, "top": 8}[options.subtitlePosition]
    escaped = str(srt_path).replace("\\", r"\\").replace(":", r"\:").replace("'", r"\'")
    force_style = f"FontName=Noto Sans Myanmar,FontSize={options.subtitleSize},PrimaryColour={ass_color(options.subtitleColor)},OutlineColour=&H90000000,BorderStyle=1,Outline=2,Shadow=1,Alignment={alignment},MarginV=38"
    return f"subtitles=filename='{escaped}':force_style='{force_style}'"


def overlay_position(position: str) -> tuple[str, str]:
    gap = 28
    mapping = {
        "top-left": (str(gap), str(gap)),
        "top-right": (f"W-w-{gap}", str(gap)),
        "bottom-left": (str(gap), f"H-h-{gap}"),
        "bottom-right": (f"W-w-{gap}", f"H-h-{gap}"),
    }
    return mapping[position]


def build_ffmpeg_command(job: dict[str, Any], movie: dict[str, Any], audio: dict[str, Any], srt: dict[str, Any] | None, logo: dict[str, Any] | None) -> tuple[list[str], float]:
    options = RenderOptions.model_validate(job["payload"]["options"])
    movie_path = Path(movie["storedPath"])
    audio_path = Path(audio["storedPath"])
    duration = max(1, float(movie["metadata"].get("duration") or 1))
    command = ["ffmpeg", "-y", "-hide_banner", "-i", str(movie_path), "-i", str(audio_path)]
    logo_index: int | None = None
    if logo:
        logo_index = 2
        command += ["-loop", "1", "-i", str(logo["storedPath"])]

    video_chain: list[str] = []
    if options.rotation == "90":
        video_chain.append("transpose=1")
    elif options.rotation == "180":
        video_chain.extend(["hflip", "vflip"])
    elif options.rotation == "270":
        video_chain.append("transpose=2")
    if options.flipHorizontal:
        video_chain.append("hflip")
    if options.flipVertical:
        video_chain.append("vflip")
    if options.videoSpeed != 1:
        video_chain.append(f"setpts=PTS/{options.videoSpeed:.5f}")
    if options.quality == "720p":
        video_chain.append("scale='min(1280,iw)':-2")
    elif options.quality == "1080p":
        video_chain.append("scale='min(1920,iw)':-2")

    filters: list[str] = []
    source_label = "[0:v]"
    if options.blurOriginalSubtitles:
        # percentages are calculated by FFmpeg against current input dimensions.
        blur_x = min(options.blurX, 99)
        blur_y = min(options.blurY, 99)
        blur_width = min(options.blurWidth, max(1, 100 - blur_x))
        blur_height = min(options.blurHeight, max(1, 100 - blur_y))
        crop_w = f"trunc(iw*{blur_width / 100:.4f}/2)*2"
        crop_h = f"trunc(ih*{blur_height / 100:.4f}/2)*2"
        crop_x = f"trunc(iw*{blur_x / 100:.4f}/2)*2"
        crop_y = f"trunc(ih*{blur_y / 100:.4f}/2)*2"
        overlay_x = f"trunc(main_w*{blur_x / 100:.4f}/2)*2"
        overlay_y = f"trunc(main_h*{blur_y / 100:.4f}/2)*2"
        filters.append(f"[0:v]split=2[vbase][vblur];[vblur]crop={crop_w}:{crop_h}:{crop_x}:{crop_y},boxblur={options.blurStrength}:1[blurred];[vbase][blurred]overlay={overlay_x}:{overlay_y}[vstage]")
        source_label = "[vstage]"
    else:
        # Map an explicit filter output even when the user selected no visual effects.
        filters.append("[0:v]null[vstage]")
        source_label = "[vstage]"
    if video_chain:
        filters.append(f"{source_label}{','.join(video_chain)}[vtransformed]")
        source_label = "[vtransformed]"
    if srt:
        filters.append(f"{source_label}{style_filter(Path(srt['storedPath']), options)}[vsub]")
        source_label = "[vsub]"
    if logo_index is not None:
        x, y = overlay_position(options.logoPosition)
        filters.append(f"[{logo_index}:v]scale=iw*0.15:-1[logo];{source_label}[logo]overlay={x}:{y}[vfinal]")
        source_label = "[vfinal]"

    has_movie_audio = bool(movie["metadata"].get("hasAudio"))
    output_audio_label = "[afinal]"
    audio_speed = atempo_filter(options.videoSpeed)
    if has_movie_audio and options.includeOriginalAudio:
        filters.append(f"[0:a]volume=0.22,{audio_speed}[background];[1:a]volume=1.20,{audio_speed}[narration];[background][narration]amix=inputs=2:duration=first:dropout_transition=2{output_audio_label}")
    else:
        filters.append(f"[1:a]volume=1.20,{audio_speed}{output_audio_label}")

    output_name = job["payload"]["outputName"]
    output_path = OUTPUT_ROOT / output_name
    command += [
        "-filter_complex", ";".join(filters),
        "-map", source_label,
        "-map", output_audio_label,
        "-c:v", "libx264", "-preset", "medium", "-crf", "20" if options.quality == "1080p" else "23",
        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-shortest", str(output_path),
    ]
    return command, duration / options.videoSpeed


async def run_render_job(job_id: str) -> None:
    job = STORE.get_job(job_id)
    if not job or job["status"] == "cancelled":
        return
    try:
        payload = job["payload"]
        owner = UserContext(subject_id=job["ownerId"])
        movie = owned_asset(payload["movieId"], owner, "movie")
        audio = owned_asset(payload["audioId"], owner, "audio")
        caption_srt_id = payload.get("narrationSrtId") or payload.get("srtId")
        srt = owned_asset(caption_srt_id, owner, "srt") if caption_srt_id else None
        logo = owned_asset(payload["logoId"], owner, "logo") if payload.get("logoId") else None
        command, target_duration = build_ffmpeg_command(job, movie, audio, srt, logo)
        current_before_start = STORE.get_job(job_id)
        if not current_before_start or current_before_start["status"] == "cancelled":
            return
        STORE.update_job(job_id, status="processing", progress=1, message="FFmpeg is starting the real media render.")
        process = await asyncio.create_subprocess_exec(*command, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
        RUNNING_PROCESSES[job_id] = process
        last_progress = 1.0
        stderr_tail: list[str] = []
        time_pattern = re.compile(r"time=(\d{2}):(\d{2}):(\d{2})\.(\d{2})")
        assert process.stderr is not None
        while line := await process.stderr.readline():
            decoded = line.decode(errors="replace")
            stderr_tail.append(decoded.strip())
            if len(stderr_tail) > 12:
                stderr_tail.pop(0)
            current_during_render = STORE.get_job(job_id)
            if current_during_render and current_during_render["status"] == "cancelled":
                if process.returncode is None:
                    process.terminate()
                break
            match = time_pattern.search(decoded)
            if match:
                hours, minutes, seconds, centiseconds = map(int, match.groups())
                elapsed = hours * 3600 + minutes * 60 + seconds + centiseconds / 100
                progress = min(98.0, max(last_progress, elapsed / target_duration * 98.0))
                if progress - last_progress >= 0.5:
                    last_progress = progress
                    STORE.update_job(job_id, progress=round(progress, 1), message="Rendering video, narration, subtitles and branding with FFmpeg.")
        exit_code = await process.wait()
        RUNNING_PROCESSES.pop(job_id, None)
        current = STORE.get_job(job_id)
        if current and current["status"] == "cancelled":
            return
        if exit_code != 0:
            diagnostic = " ".join(line for line in stderr_tail if line)
            raise RuntimeError(f"FFmpeg exited with code {exit_code}. {diagnostic[-850:]}")
        output_path = OUTPUT_ROOT / payload["outputName"]
        if not output_path.is_file() or output_path.stat().st_size == 0:
            raise RuntimeError("FFmpeg reported success but no usable MP4 output was created.")
        STORE.update_job(job_id, status="completed", progress=100, message="Final MP4 is ready for download.", outputName=payload["outputName"])
    except Exception as error:
        RUNNING_PROCESSES.pop(job_id, None)
        with contextlib.suppress(OSError):
            output_name = job.get("payload", {}).get("outputName")
            if output_name:
                (OUTPUT_ROOT / Path(output_name).name).unlink(missing_ok=True)
        STORE.update_job(job_id, status="failed", progress=0, message="Rendering failed.", error=str(error)[:1000])
        STORE.refund_job_once(job_id)


app = FastAPI(title="MovieRecap AI API", version="0.1.0")


@app.exception_handler(HTTPException)
async def http_exception_handler(_: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"error": {"message": exc.detail, "status": exc.status_code}})


@app.get("/health")
@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {"status": "ok", "service": "MovieRecap AI FastAPI", "ffmpeg": FFMPEG_AVAILABLE, "time": now_iso()}


@app.get("/capabilities")
@app.get("/api/capabilities")
async def capabilities() -> dict[str, Any]:
    return {
        "ffmpeg": FFMPEG_AVAILABLE,
        "aiRecap": ai_provider() is not None,
        "tts": bool(os.getenv("OPENAI_API_KEY")),
        "database": "mysql" if STORE.is_mysql else "sqlite-local",
        "durableStorage": False,
        "creditSystem": True,
        "androidClient": "PWA ready; FastAPI endpoints are App Inventor-compatible.",
        "productionReady": False,
        "notes": [
            "Large media uploads use this server's filesystem in this build. Configure durable object storage before public deployment.",
            "AI/TTS only run with server-held credentials and fail clearly when unavailable.",
        ],
    }


@app.post("/self-test")
@app.post("/api/self-test")
async def self_test() -> dict[str, Any]:
    ffmpeg_result = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, check=False, timeout=15) if FFMPEG_AVAILABLE else None
    writable = all(os.access(directory, os.W_OK) for directory in (UPLOAD_ROOT, OUTPUT_ROOT, TMP_ROOT))
    return {
        "ok": bool(FFMPEG_AVAILABLE and ffmpeg_result and ffmpeg_result.returncode == 0 and writable),
        "checks": {
            "ffmpeg": bool(ffmpeg_result and ffmpeg_result.returncode == 0),
            "dataDirectoryWritable": writable,
            "database": "mysql" if STORE.is_mysql else "sqlite-local",
            "aiConfigured": ai_provider() is not None,
            "ttsConfigured": bool(os.getenv("OPENAI_API_KEY")),
        },
    }


@app.get("/session")
@app.get("/api/session")
async def get_session(user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    return STORE.credit_state(user.subject_id)


@app.post("/admin/unlock")
@app.post("/api/admin/unlock")
async def unlock_admin(payload: AdminUnlockRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    admin_token = os.getenv("ADMIN_TOKEN")
    if not admin_token:
        raise HTTPException(status_code=503, detail="Owner mode is not configured on this server. Set ADMIN_TOKEN only in the server environment.")
    if not hashlib.sha256(payload.token.encode()).digest() == hashlib.sha256(admin_token.encode()).digest():
        raise HTTPException(status_code=403, detail="The owner token was not accepted.")
    STORE.unlock_admin(user.subject_id)
    return {**STORE.credit_state(user.subject_id), "message": "Owner mode is active for this signed server session."}


@app.post("/upload/movie")
@app.post("/api/upload/movie")
async def upload_movie(file: UploadFile = File(...), user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    return {"upload": await write_upload(file, "movie", user)}


@app.post("/upload/movie-url")
@app.post("/api/upload/movie-url")
async def upload_movie_url(payload: SourceUrlRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    if yt_dlp is None:
        raise HTTPException(status_code=503, detail="Link download tool is not installed on this server. Upload the video file instead.")
    asset_id = f"ast_{uuid.uuid4().hex}"
    output_template = str(TMP_ROOT / f"{asset_id}.%(ext)s")

    def download() -> tuple[Path, dict[str, Any]]:
        options = {
            "outtmpl": output_template,
            "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
            "merge_output_format": "mp4",
            "noplaylist": True,
            "quiet": True,
            "no_warnings": True,
            "max_filesize": MAX_FILE_BYTES,
        }
        downloader_cls = cast(Any, yt_dlp).YoutubeDL
        with downloader_cls(options) as downloader:
            info = cast(dict[str, Any], downloader.extract_info(payload.url, download=True))
        candidates = sorted(TMP_ROOT.glob(f"{asset_id}.*"), key=lambda item: item.stat().st_mtime, reverse=True)
        if not candidates:
            raise RuntimeError("The source platform did not return a downloadable video file.")
        return candidates[0], info

    try:
        source_path, info = await asyncio.to_thread(download)
        final_path = UPLOAD_ROOT / f"{asset_id}_{safe_name(info.get('title') or 'linked-video')}.mp4"
        source_path.replace(final_path)
        metadata = probe_media(final_path)
        asset = {"assetId": asset_id, "ownerId": user.subject_id, "kind": "movie", "originalName": final_path.name, "storedPath": str(final_path), "contentType": "video/mp4", "sizeBytes": final_path.stat().st_size, "metadata": {**metadata, "sourceUrl": payload.url, "sourceTitle": info.get("title")}, "createdAt": now_iso()}
        STORE.create_asset(asset)
        return {"upload": public_asset(asset), "source": "linked video downloaded and validated"}
    except Exception as error:
        for candidate in TMP_ROOT.glob(f"{asset_id}.*"):
            candidate.unlink(missing_ok=True)
        raise HTTPException(status_code=422, detail=f"Could not download this link: {error}") from error


@app.post("/upload/srt")
@app.post("/api/upload/srt")
async def upload_srt(file: UploadFile = File(...), user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    return {"upload": await write_upload(file, "srt", user)}


@app.post("/upload/audio")
@app.post("/api/upload/audio")
async def upload_audio(file: UploadFile = File(...), user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    return {"upload": await write_upload(file, "audio", user)}


@app.post("/upload/logo")
@app.post("/api/upload/logo")
async def upload_logo(file: UploadFile = File(...), user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    return {"upload": await write_upload(file, "logo", user)}


@app.post("/recap/generate")
@app.post("/api/recap/generate")
async def generate_recap(payload: RecapRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    srt = owned_asset(payload.srtId, user, "srt")
    credit = STORE.consume_credits(user.subject_id, 1, "AI recap")
    try:
        script = await call_recap_ai(srt["metadata"]["cues"], payload.language, payload.targetSeconds, payload.narratorMode)
    except Exception:
        STORE.refund_credits(user.subject_id, 1)
        raise
    estimated_seconds = round(len(script.split()) / (2.25 if payload.language == "Burmese" else 2.55))
    return {"script": script, "estimatedSeconds": estimated_seconds, "credit": STORE.credit_state(user.subject_id), "sourceCueCount": srt["metadata"].get("cueCount", 0)}


@app.post("/recap/plan")
@app.post("/api/recap/plan")
async def recap_plan(payload: ScenePlanRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    srt = owned_asset(payload.srtId, user, "srt")
    scenes = split_scenes(srt["metadata"]["cues"], payload.maxCuesPerScene, payload.pauseSeconds)
    return {"scenes": scenes, "sceneCount": len(scenes), "timelineSeconds": srt["metadata"].get("duration", 0)}


@app.post("/subtitles/from-script")
@app.post("/api/subtitles/from-script")
async def subtitles_from_script(payload: TimedSubtitleRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    try:
        content = timed_srt(payload.text, payload.durationSeconds).encode("utf-8")
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    asset_id = f"ast_{uuid.uuid4().hex}"
    path = UPLOAD_ROOT / f"{asset_id}_narration-timed.srt"
    path.write_bytes(content)
    cues = parse_srt_text(content.decode("utf-8"))
    asset = {"assetId": asset_id, "ownerId": user.subject_id, "kind": "srt", "originalName": "narration-timed.srt", "storedPath": str(path), "contentType": "application/x-subrip", "sizeBytes": len(content), "metadata": {"cues": cues, "cueCount": len(cues), "duration": cues[-1]["end"], "generated": True}, "createdAt": now_iso()}
    STORE.create_asset(asset)
    return {"upload": public_asset(asset), "source": "sentence-weighted narration timing"}


@app.post("/subtitles/translate")
@app.post("/api/subtitles/translate")
async def translate_subtitles(payload: TranslateSubtitleRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    source = owned_asset(payload.srtId, user, "srt")
    STORE.consume_credits(user.subject_id, 1, "SRT translation")
    try:
        cues = await translate_srt_cues(source["metadata"]["cues"], payload.targetLanguage)
        content = "\n\n".join(f"{index}\n{cue['startTime']} --> {cue['endTime']}\n{cue['text']}" for index, cue in enumerate(cues, 1)) + "\n"
        asset_id = f"ast_{uuid.uuid4().hex}"
        path = UPLOAD_ROOT / f"{asset_id}_translated-{payload.targetLanguage.lower()}.srt"
        path.write_text(content, encoding="utf-8")
        asset = {"assetId": asset_id, "ownerId": user.subject_id, "kind": "srt", "originalName": path.name, "storedPath": str(path), "contentType": "application/x-subrip", "sizeBytes": path.stat().st_size, "metadata": {"cues": cues, "cueCount": len(cues), "duration": cues[-1]["end"], "translated": True, "language": payload.targetLanguage}, "createdAt": now_iso()}
        STORE.create_asset(asset)
        return {"upload": public_asset(asset), "credit": STORE.credit_state(user.subject_id), "source": "AI translated SRT with original timings preserved"}
    except Exception:
        STORE.refund_credits(user.subject_id, 1)
        raise


@app.post("/subtitles/from-audio-translate")
@app.post("/api/subtitles/from-audio-translate")
async def audio_to_translated_subtitles(payload: AudioTranslateRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    movie = owned_asset(payload.movieId, user, "movie")
    STORE.consume_credits(user.subject_id, 2, "audio transcription and translation")
    try:
        source_cues = await transcribe_movie_audio(Path(movie["storedPath"]))
        translated_cues = await translate_srt_cues(source_cues, payload.targetLanguage)
        content = "\n\n".join(f"{index}\n{cue['startTime']} --> {cue['endTime']}\n{cue['text']}" for index, cue in enumerate(translated_cues, 1)) + "\n"
        asset_id = f"ast_{uuid.uuid4().hex}"
        path = UPLOAD_ROOT / f"{asset_id}_audio-translated-{payload.targetLanguage.lower()}.srt"
        path.write_text(content, encoding="utf-8")
        asset = {"assetId": asset_id, "ownerId": user.subject_id, "kind": "srt", "originalName": path.name, "storedPath": str(path), "contentType": "application/x-subrip", "sizeBytes": path.stat().st_size, "metadata": {"cues": translated_cues, "cueCount": len(translated_cues), "duration": translated_cues[-1]["end"], "translated": True, "fromAudio": True, "language": payload.targetLanguage}, "createdAt": now_iso()}
        STORE.create_asset(asset)
        return {"upload": public_asset(asset), "credit": STORE.credit_state(user.subject_id), "source": "speech-to-text then translated SRT"}
    except Exception:
        STORE.refund_credits(user.subject_id, 2)
        raise


@app.post("/tts/generate")
@app.post("/api/tts/generate")
async def generate_tts(payload: TtsRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    STORE.consume_credits(user.subject_id, 1, "TTS narration")
    try:
        content = await synthesize_tts(payload.text, payload.voice, payload.voiceGender, payload.style, payload.speed, payload.language)
        asset_id = f"ast_{uuid.uuid4().hex}"
        filename = f"{asset_id}_narration.mp3"
        path = UPLOAD_ROOT / filename
        path.write_bytes(content)
        metadata = probe_media(path)
        asset = {
            "assetId": asset_id, "ownerId": user.subject_id, "kind": "audio", "originalName": "ai-narration.mp3", "storedPath": str(path),
            "contentType": "audio/mpeg", "sizeBytes": len(content), "metadata": metadata, "createdAt": now_iso(),
        }
        STORE.create_asset(asset)
    except Exception:
        STORE.refund_credits(user.subject_id, 1)
        raise
    return {"upload": public_asset(asset), "credit": STORE.credit_state(user.subject_id)}


@app.post("/copyright/check")
@app.post("/api/copyright/check")
async def copyright_check(payload: CopyrightRequest) -> dict[str, Any]:
    return calculate_risk(payload)


@app.post("/jobs/from-uploads")
@app.post("/api/jobs/from-uploads")
async def create_render_job(payload: RenderRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    movie = owned_asset(payload.movieId, user, "movie")
    if not payload.audioId:
        raise HTTPException(status_code=422, detail="Rendering needs narration audio. Generate TTS or upload a narration track first.")
    owned_asset(payload.audioId, user, "audio")
    if payload.srtId:
        owned_asset(payload.srtId, user, "srt")
    if payload.narrationSrtId:
        owned_asset(payload.narrationSrtId, user, "srt")
    if payload.logoId:
        owned_asset(payload.logoId, user, "logo")
    copyright_result = calculate_risk(payload.copyright)
    if copyright_result["risk"] == "High" and not payload.highRiskAcknowledged:
        raise HTTPException(status_code=409, detail="High copyright risk must be acknowledged before export. This cannot guarantee safety.")
    credit_cost = 2
    STORE.consume_credits(user.subject_id, credit_cost, "FFmpeg export")
    job_id = f"job_{uuid.uuid4().hex}"
    output_name = f"{payload.filename}-{job_id[-8:]}.mp4"
    job = {
        "jobId": job_id,
        "ownerId": user.subject_id,
        "status": "queued",
        "progress": 0,
        "message": "Render job accepted and waiting for FFmpeg.",
        "payload": {**payload.model_dump(), "copyrightRisk": copyright_result["risk"], "outputName": output_name, "sourceDuration": movie["metadata"].get("duration")},
        "creditCost": credit_cost,
        "createdAt": now_iso(),
        "updatedAt": now_iso(),
    }
    STORE.create_job(job)
    asyncio.create_task(run_render_job(job_id))
    return {"jobId": job_id, "status": "queued", "progress": 0, "credit": STORE.credit_state(user.subject_id)}


@app.get("/jobs/{job_id}")
@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    job = STORE.get_job(job_id, user.subject_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found for this session.")
    response = {key: job[key] for key in ("jobId", "status", "progress", "message", "error", "createdAt", "updatedAt")}
    if job.get("outputName") and job["status"] == "completed":
        response["outputUrl"] = f"/outputs/{job['outputName']}"
    return response


@app.post("/jobs/{job_id}/cancel")
@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str, payload: CancelRequest, user: UserContext = Depends(ensure_user)) -> dict[str, Any]:
    job = STORE.get_job(job_id, user.subject_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found for this session.")
    if job["status"] in {"completed", "failed", "cancelled"}:
        return {"jobId": job_id, "status": job["status"], "message": "This job is already in a terminal state."}
    process = RUNNING_PROCESSES.get(job_id)
    if process and process.returncode is None:
        process.terminate()
    STORE.update_job(job_id, status="cancelled", message=payload.reason, progress=0)
    STORE.refund_job_once(job_id)
    return {"jobId": job_id, "status": "cancelled", "message": payload.reason}


@app.get("/outputs/{filename}")
async def get_output(filename: str, user: UserContext = Depends(ensure_user)) -> FileResponse:
    safe_filename = Path(filename).name
    path = OUTPUT_ROOT / safe_filename
    if not path.is_file() or path.suffix.lower() != ".mp4":
        raise HTTPException(status_code=404, detail="Output MP4 was not found.")
    job = STORE.get_job_by_output(safe_filename, user.subject_id)
    if not job or job["status"] != "completed":
        raise HTTPException(status_code=404, detail="Output MP4 was not found for this signed session.")
    return FileResponse(path, media_type="video/mp4", filename=safe_filename)


@app.get("/assets/{asset_id}/preview")
async def get_asset_preview(asset_id: str, user: UserContext = Depends(ensure_user)) -> FileResponse:
    asset = owned_asset(asset_id, user)
    return FileResponse(asset["storedPath"], media_type=asset.get("contentType") or "application/octet-stream", filename=asset["originalName"])


@app.get("/manus-routes.json")
async def route_manifest() -> FileResponse:
    manifest = DIST_ROOT / "manus-routes.json"
    if not manifest.is_file():
        source_manifest = APP_ROOT / "client" / "public" / "manus-routes.json"
        if source_manifest.is_file():
            manifest = source_manifest
        else:
            raise HTTPException(status_code=503, detail="Route manifest is missing. Run pnpm build:static.")
    return FileResponse(manifest, media_type="application/json")


@app.get("/api/platform/config.js")
async def platform_config() -> FileResponse:
    config = DIST_ROOT / "api" / "platform" / "config.js"
    if not config.is_file():
        raise HTTPException(status_code=503, detail="Public platform config is missing. Run pnpm build:static.")
    return FileResponse(config, media_type="application/javascript", headers={"Cache-Control": "no-store"})


if DIST_ROOT.is_dir():
    app.mount("/assets", StaticFiles(directory=DIST_ROOT / "assets"), name="assets")


@app.get("/{path:path}")
async def spa(path: str):
    # API/asset misses receive JSON rather than an index fallback, so integrations get a real error.
    if path.startswith(("api/", "assets/", "outputs/", "upload/", "jobs/", "recap/", "tts/", "copyright/", "session", "admin/", "health", "capabilities", "self-test")):
        raise HTTPException(status_code=404, detail="API route not found.")
    index = DIST_ROOT / "index.html"
    if index.is_file():
        return FileResponse(index)
    return JSONResponse(status_code=503, content={"error": {"message": "Frontend bundle is missing. Run pnpm build:static.", "status": 503}})


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=int(os.getenv("PORT", "3000")), reload=os.getenv("RELOAD", "0") == "1")
